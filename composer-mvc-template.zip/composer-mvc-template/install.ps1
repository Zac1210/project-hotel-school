# Script de Instalacao do Projeto
# Execute: .\install.ps1

Write-Host "Instalando dependencias do projeto..." -ForegroundColor Green

# Verificar se o PHP esta instalado
Write-Host "`nVerificando PHP..." -ForegroundColor Yellow
$phpVersion = php -v 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Host "PHP nao encontrado! Por favor, instale o PHP primeiro." -ForegroundColor Red
    exit 1
}
Write-Host "PHP encontrado" -ForegroundColor Green

# Verificar OpenSSL
Write-Host "`nVerificando extensao OpenSSL..." -ForegroundColor Yellow
$openssl = php -m 2>&1 | Select-String "openssl"
if (-not $openssl) {
    Write-Host "OpenSSL nao esta habilitado!" -ForegroundColor Yellow
    Write-Host "`nPara habilitar o OpenSSL:" -ForegroundColor Yellow
    Write-Host "1. Localize o arquivo php.ini (execute: php --ini)" -ForegroundColor Cyan
    Write-Host "2. Abra o php.ini e procure por: ;extension=openssl" -ForegroundColor Cyan
    Write-Host "3. Remova o ponto e virgula: extension=openssl" -ForegroundColor Cyan
    Write-Host "4. Salve o arquivo e reinicie o PHP/servidor" -ForegroundColor Cyan
    Write-Host "`nOu tente localizar o php.ini:" -ForegroundColor Yellow
    php --ini
    Write-Host "`nContinuando sem OpenSSL (composer install pode falhar)..." -ForegroundColor Yellow
} else {
    Write-Host "OpenSSL esta habilitado" -ForegroundColor Green
}

# Criar arquivo .env se nao existir
Write-Host "`nVerificando arquivo .env..." -ForegroundColor Yellow
if (-not (Test-Path ".env")) {
    Write-Host "Criando arquivo .env a partir do template..." -ForegroundColor Yellow
    $envContent = "# Database Configuration`r`nDB_CONNECTION=mysql`r`nDB_HOST=localhost`r`nDB_PORT=3306`r`nDB_DATABASE=mydatabase`r`nDB_USERNAME=root`r`nDB_PASSWORD=`r`n`r`n# Authentication Configuration`r`nAUTH_SECRET_KEY=change-this-secret-key-in-production" + (Get-Random -Minimum 1000 -Maximum 9999) + "`r`nAUTH_TOKEN_ALGORITHM=sha256`r`nAUTH_TOKEN_EXPIRY=86400`r`nAUTH_SESSION_EXPIRY=1800`r`nAUTH_SESSION_REGENERATE=1800`r`nAUTH_REMEMBER_EXPIRY=2592000`r`n`r`n# Email Configuration (Optional)`r`nMAIL_HOST=smtp.gmail.com`r`nMAIL_PORT=587`r`nMAIL_USERNAME=`r`nMAIL_PASSWORD=`r`nMAIL_FROM_ADDRESS=noreply@example.com`r`nMAIL_FROM_NAME=System`r`nSUPPORT_EMAIL=support@example.com`r`n`r`n# Application Configuration`r`nAPP_ENV=development`r`nAPP_DEBUG=true"
    [System.IO.File]::WriteAllText((Resolve-Path .).Path + "\.env", $envContent, [System.Text.Encoding]::UTF8)
    Write-Host "Arquivo .env criado! Por favor, edite-o com suas configuracoes." -ForegroundColor Green
} else {
    Write-Host "Arquivo .env ja existe" -ForegroundColor Green
}

# Tentar instalar dependencias
Write-Host "`nInstalando dependencias do Composer..." -ForegroundColor Yellow
composer install --no-interaction
if ($LASTEXITCODE -eq 0) {
    Write-Host "Dependencias instaladas com sucesso!" -ForegroundColor Green
} else {
    Write-Host "Falha ao instalar dependencias. Verifique se o OpenSSL esta habilitado." -ForegroundColor Red
    Write-Host "Consulte ENV_SETUP.md para mais informacoes." -ForegroundColor Yellow
}

Write-Host "`nInstalacao concluida!" -ForegroundColor Green
Write-Host "`nProximos passos:" -ForegroundColor Yellow
Write-Host "1. Edite o arquivo .env com suas configuracoes de banco de dados" -ForegroundColor Cyan
Write-Host "2. Execute: composer schema (para configurar o banco)" -ForegroundColor Cyan
Write-Host "3. Execute: composer dev (para iniciar o servidor)" -ForegroundColor Cyan
