# Rotas do Projeto

Este documento lista todas as rotas disponíveis no projeto.

## 🔐 Rotas de Autenticação

| Método | Rota | Controller | Descrição |
|--------|------|------------|-----------|
| GET | `/auth` | `AuthController@showAuth` | Página de login/registro |
| POST | `/login` | `AuthController@login` | Processa login |
| POST | `/register` | `AuthController@register` | Processa registro |
| GET/POST | `/logout` | `AuthController@logout` | Faz logout |

## 🏠 Rotas Públicas

| Método | Rota | Controller | Descrição |
|--------|------|------------|-----------|
| GET | `/` | `HomeController@index` | Página inicial |
| GET | `/about` | `HomeController@about` | Sobre |
| GET | `/contact` | `HomeController@contact` | Contato |

## 📝 Rotas de Posts (Requer Autenticação)

| Método | Rota | Controller | Descrição |
|--------|------|------------|-----------|
| GET | `/posts` | `PostController@index` | Lista todos os posts do usuário |
| GET | `/posts/{id}` | `PostController@show` | Visualiza um post específico |
| GET/POST | `/posts/create` | `PostController@create` | Cria novo post (GET: formulário, POST: processa) |
| GET | `/new-post` | `PostController@create` | Alias para `/posts/create` |
| POST | `/posts/store` | `PostController@store` | Processa criação de post |
| GET/POST | `/posts/{id}/edit` | `PostController@edit` | Edita post (GET: formulário, POST: processa) |
| POST | `/posts/{id}/update` | `PostController@update` | Processa atualização de post |
| POST | `/posts/{id}/delete` | `PostController@delete` | Deleta um post |

## 🌐 Rotas da API

### Usuários

| Método | Rota | Controller | Descrição |
|--------|------|------------|-----------|
| GET | `/api/users` | `Api\UserController@index` | Lista todos os usuários (JSON) |
| GET | `/api/users/{id}` | `Api\UserController@show` | Mostra um usuário específico (JSON) |

### Posts

| Método | Rota | Controller | Descrição |
|--------|------|------------|-----------|
| GET | `/api/posts` | `Api\PostController@index` | Lista todos os posts (JSON) |
| GET | `/api/posts/{id}` | `Api\PostController@show` | Mostra um post específico (JSON) |

### Autenticação API

| Método | Rota | Controller | Descrição |
|--------|------|------------|-----------|
| POST | `/api/auth/login` | `Api\AuthController@login` | Login via API (JSON) |

## 📌 Notas Importantes

1. **Autenticação**: Rotas marcadas como "Requer Autenticação" redirecionam para `/auth` se o usuário não estiver logado
2. **CSRF Protection**: Formulários POST requerem token CSRF
3. **JSON Responses**: Todas as rotas da API retornam JSON
4. **404**: Qualquer rota não encontrada é direcionada para `HomeController@notFound`


