<?php

/**
 * Script para criar usuários de teste (diferentes roles)
 * Execute: php db/create-test-users.php
 */

require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/connection.php';

use Source\Models\User;
use Core\Helpers\ORMHelper;

echo "🏨 Hotel-Moz - Criando Usuários de Teste\n";
echo str_repeat("=", 50) . "\n\n";

$testUsers = [
    [
        'name' => 'Administrador',
        'email' => 'admin@hotelmoz.com',
        'password' => 'admin123',
        'role' => 'admin',
        'phone' => '+258 84 000 0001'
    ],
    [
        'name' => 'Cliente Teste',
        'email' => 'cliente@teste.com',
        'password' => 'cliente123',
        'role' => 'client',
        'phone' => '+258 84 000 0002'
    ],
    [
        'name' => 'Recepcionista Teste',
        'email' => 'recepcao@hotelmoz.com',
        'password' => 'recep123',
        'role' => 'receptionist',
        'phone' => '+258 84 000 0003'
    ],
    [
        'name' => 'Camareira Teste',
        'email' => 'camareira@hotelmoz.com',
        'password' => 'camareira123',
        'role' => 'housekeeper',
        'phone' => '+258 84 000 0004'
    ],
    [
        'name' => 'Gerente Teste',
        'email' => 'gerente@hotelmoz.com',
        'password' => 'gerente123',
        'role' => 'manager',
        'phone' => '+258 84 000 0005'
    ]
];

$created = 0;
$skipped = 0;

try {
    foreach ($testUsers as $userData) {
        // Verificar se usuário já existe
        $existing = ORMHelper::select(User::class)
            ->where('email', $userData['email'])
            ->fetchOne();

        if ($existing) {
            echo "⏭️  Pulando: {$userData['email']} (já existe)\n";
            $skipped++;
            continue;
        }

        // Criar usuário
        $user = new User();
        $user->name = $userData['name'];
        $user->email = $userData['email'];
        $user->password = password_hash($userData['password'], PASSWORD_DEFAULT);
        $user->role = $userData['role'];
        $user->phone = $userData['phone'] ?? null;
        $user->address = 'Hotel-Moz, Moçambique';

        $manager = ORMHelper::getManager();
        $manager->persist($user);
        $manager->run();

        echo "✅ Criado: {$userData['email']} ({$userData['role']})\n";
        $created++;
    }

    echo "\n" . str_repeat("=", 50) . "\n";
    echo "📊 Resumo:\n";
    echo "   Criados: {$created}\n";
    echo "   Pulados: {$skipped}\n";
    echo str_repeat("=", 50) . "\n\n";
    
    echo "📋 Credenciais de Teste:\n";
    echo str_repeat("-", 50) . "\n";
    foreach ($testUsers as $userData) {
        echo "Role: {$userData['role']}\n";
        echo "Email: {$userData['email']}\n";
        echo "Senha: {$userData['password']}\n";
        echo str_repeat("-", 50) . "\n";
    }
    
    echo "\n🌐 Acesse: http://localhost:8000/auth\n";
    echo "💡 Use qualquer uma das credenciais acima para fazer login\n";
    
} catch (Exception $e) {
    echo "❌ Erro ao criar usuários: " . $e->getMessage() . "\n";
    echo "\nVerifique:\n";
    echo "1. Se o banco de dados está configurado corretamente\n";
    echo "2. Se as tabelas foram criadas (execute: composer schema)\n";
    exit(1);
}


