<?php

use Dotenv\Dotenv;
use Cycle\Database;
use Cycle\Database\Config;

$dotenv = Dotenv::createImmutable(__DIR__ . '/../');
$dotenv->load();

$connection = $_ENV['DB_CONNECTION'] ?? 'sqlite';

$dbConfig = new Config\DatabaseConfig([
    'default' => 'default',
    'databases' => [
        'default' => ['connection' => $connection]
    ],
    'connections' => [
        'sqlite' => new Config\SQLiteDriverConfig(
            connection: new Config\SQLite\FileConnectionConfig(
                database: $_ENV['DB_DATABASE'] ?? __DIR__ . '/../database.sqlite'
            )
        ),
        'mysql' => new Config\MySQLDriverConfig(
            connection: new Config\MySQL\TcpConnectionConfig(
                database: $_ENV['DB_DATABASE'] ?? 'database',
                host: $_ENV['DB_HOST'] ?? 'localhost',
                port: (int) ($_ENV['DB_PORT'] ?? 3306),
                user: $_ENV['DB_USERNAME'] ?? 'root',
                password: $_ENV['DB_PASSWORD'] ?? ''
            ),
            queryCache: true
        )
    ]
]);

$database = new Database\DatabaseManager($dbConfig);

return $database;