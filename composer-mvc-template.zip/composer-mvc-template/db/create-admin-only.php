<?php

/**
 * Script para criar APENAS o usuário administrador
 * Remove todos os outros usuários antes de criar
 * Execute: php db/create-admin-only.php
 */

require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/connection.php';

use Source\Models\User;
use Core\Helpers\ORMHelper;

echo "🏨 Hotel-Moz - Criando Usuário Administrador\n";
echo str_repeat("=", 50) . "\n\n";

// Dados do administrador
$adminEmail = 'admin@hotelmoz.com';
$adminPassword = 'admin123';
$adminName = 'Administrador';

echo "⚠️  Este script irá DELETAR todos os usuários existentes!\n";
echo "Deseja continuar? (s/n): ";
$handle = fopen("php://stdin", "r");
$line = fgets($handle);
$confirmation = trim(strtolower($line));
fclose($handle);

if ($confirmation !== 's' && $confirmation !== 'sim' && $confirmation !== 'y' && $confirmation !== 'yes') {
    echo "\n❌ Operação cancelada.\n";
    exit(0);
}

try {
    echo "\n🗑️  Removendo usuários existentes...\n";
    
    // Buscar todos os usuários
    $allUsers = ORMHelper::select(User::class)->fetchAll();
    $deletedCount = 0;
    
    if (!empty($allUsers)) {
        $manager = ORMHelper::getManager();
        foreach ($allUsers as $user) {
            $manager->delete($user);
            $deletedCount++;
        }
        $manager->run();
        echo "✅ Usuários removidos: {$deletedCount}\n\n";
    } else {
        echo "ℹ️  Nenhum usuário encontrado para remover.\n\n";
    }

    // Criar novo administrador
    echo "👤 Criando usuário administrador...\n";
    
    $admin = new User();
    $admin->name = $adminName;
    $admin->email = $adminEmail;
    $admin->password = password_hash($adminPassword, PASSWORD_DEFAULT);
    $admin->role = 'admin';
    $admin->phone = '+258 84 000 0000';
    $admin->address = 'Hotel-Moz, Moçambique';

    $manager = ORMHelper::getManager();
    $manager->persist($admin);
    $manager->run();

    echo "✅ Administrador criado com sucesso!\n\n";
    echo str_repeat("=", 50) . "\n";
    echo "📋 CREDENCIAIS DE ACESSO\n";
    echo str_repeat("=", 50) . "\n";
    echo "Email: {$adminEmail}\n";
    echo "Senha: {$adminPassword}\n";
    echo "Role: admin\n";
    echo str_repeat("=", 50) . "\n\n";
    
    echo "🔒 IMPORTANTE:\n";
    echo "- Altere a senha após o primeiro login!\n";
    echo "- Mantenha essas credenciais seguras!\n";
    echo "- Em produção, use uma senha forte!\n\n";
    
    echo "🌐 Acesse: http://localhost:8000/auth\n";
    echo "🚀 Após login, você será redirecionado para /dashboard/admin\n";
    
} catch (Exception $e) {
    echo "❌ Erro: " . $e->getMessage() . "\n";
    echo "\nVerifique:\n";
    echo "1. Se o banco de dados está configurado corretamente\n";
    echo "2. Se as tabelas foram criadas (execute: composer schema)\n";
    echo "3. Se as extensões PHP necessárias estão habilitadas\n";
    exit(1);
}


