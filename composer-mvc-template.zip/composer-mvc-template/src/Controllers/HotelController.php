<?php

namespace Source\Controllers;

use Core\View;
use Core\Helpers\AuthHelper;
use Core\Helpers\MockDataHelper;

class HotelController
{
    public function index()
    {
        // Landing page pública
        View::render('hotel/landing', [
            'title' => 'Hotel-Moz - Sua Experiência Inesquecível Começa Aqui'
        ]);
    }

    public function search()
    {
        // Busca de disponibilidade
        $checkIn = $_GET['check_in'] ?? '';
        $checkOut = $_GET['check_out'] ?? '';
        $adults = (int) ($_GET['adults'] ?? 1);
        $children = (int) ($_GET['children'] ?? 0);

        if (empty($checkIn) || empty($checkOut)) {
            header('Location: /');
            exit;
        }

        // Buscar quartos disponíveis (dados mockados)
        $checkInDate = new \DateTime($checkIn);
        $checkOutDate = new \DateTime($checkOut);

        // Usar dados mockados
        $availableRooms = \Core\Helpers\MockDataHelper::getAvailableRooms($checkIn, $checkOut);

        View::render('hotel/search', [
            'title' => 'Quartos Disponíveis',
            'rooms' => $availableRooms,
            'check_in' => $checkIn,
            'check_out' => $checkOut,
            'adults' => $adults,
            'children' => $children,
            'nights' => $checkInDate->diff($checkOutDate)->days
        ]);
    }
}

