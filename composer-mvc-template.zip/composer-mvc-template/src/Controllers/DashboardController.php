<?php

namespace Source\Controllers;

use Core\View;
use Core\Helpers\AuthHelper;
use Core\Helpers\MockDataHelper;

class DashboardController
{
    public function index()
    {
        $credentials = AuthHelper::check();
        if (!$credentials) {
            header('Location: /auth');
            exit;
        }

        $role = $credentials['role'] ?? 'client';

        // Redirecionar para dashboard específico do perfil
        switch ($role) {
            case 'client':
                return $this->client();
            case 'receptionist':
                return $this->receptionist();
            case 'housekeeper':
                return $this->housekeeper();
            case 'manager':
                return $this->manager();
            case 'admin':
                return $this->admin();
            default:
                return $this->client();
        }
    }

    public function client()
    {
        // Modo desenvolvimento frontend: permite acesso sem autenticação
        $credentials = AuthHelper::check();
        if (!$credentials) {
            $credentials = [
                'user_id' => 999,
                'email' => 'cliente@example.com',
                'name' => 'Cliente Teste',
                'role' => 'client'
            ];
        }

        // Dados mockados para cliente
        $reservations = MockDataHelper::getReservations();

        View::render('dashboard/client', [
            'title' => 'Meu Painel',
            'user' => $credentials,
            'reservations' => $reservations
        ]);
    }

    public function receptionist()
    {
        // Modo desenvolvimento frontend: permite acesso sem autenticação
        $credentials = AuthHelper::check();
        if (!$credentials) {
            $credentials = [
                'user_id' => 998,
                'email' => 'receptionist@example.com',
                'name' => 'Recepcionista Teste',
                'role' => 'receptionist'
            ];
        }

        // Dados mockados para recepcionista
        $allReservations = MockDataHelper::getReservations();
        $pendingCheckins = array_filter($allReservations, fn($r) => $r['status'] === 'confirmed');
        $todayReservations = array_filter($allReservations, fn($r) => $r['status'] === 'checked_in' || $r['status'] === 'confirmed');

        View::render('dashboard/receptionist', [
            'title' => 'Dashboard Recepção',
            'user' => $credentials,
            'pending_checkins' => $pendingCheckins,
            'today_reservations' => $todayReservations
        ]);
    }

    public function housekeeper()
    {
        // Modo desenvolvimento frontend: permite acesso sem autenticação
        $credentials = AuthHelper::check();
        if (!$credentials) {
            $credentials = [
                'user_id' => 997,
                'email' => 'housekeeper@example.com',
                'name' => 'Camareira Teste',
                'role' => 'housekeeper'
            ];
        }

        // Dados mockados para camareira
        $allRooms = MockDataHelper::getRooms();
        $roomsToClean = array_filter($allRooms, fn($r) => $r['status'] === 'occupied');
        $roomsCleaning = array_filter($allRooms, fn($r) => $r['status'] === 'cleaning');

        View::render('dashboard/housekeeper', [
            'title' => 'Dashboard Limpeza',
            'user' => $credentials,
            'rooms_to_clean' => $roomsToClean,
            'rooms_cleaning' => $roomsCleaning
        ]);
    }

    public function manager()
    {
        // Modo desenvolvimento frontend: permite acesso sem autenticação
        $credentials = AuthHelper::check();
        if (!$credentials) {
            $credentials = [
                'user_id' => 996,
                'email' => 'manager@example.com',
                'name' => 'Gerente Teste',
                'role' => 'manager'
            ];
        }

        // Dados mockados para gerente
        $stats = MockDataHelper::getStats();

        View::render('dashboard/manager', [
            'title' => 'Dashboard Gerente',
            'user' => $credentials,
            'stats' => $stats
        ]);
    }

    public function admin()
    {
        // Modo desenvolvimento frontend: permite acesso sem autenticação
        $credentials = AuthHelper::check();
        if (!$credentials) {
            $credentials = [
                'user_id' => 1,
                'email' => 'admin@hotelmoz.com',
                'name' => 'Administrador',
                'role' => 'admin'
            ];
        }

        View::render('dashboard/admin', [
            'title' => 'Dashboard Administrador',
            'user' => $credentials
        ]);
    }
}

