<?php

namespace Source\Controllers\Api;

use Core\Helpers\AuthHelper;
use Core\Helpers\ORMHelper;
use Core\Helpers\ResponseHelper;
use Source\Models\User;

class AuthController
{
    public function login()
    {
        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';

        if (empty($email) || empty($password)) {
            ResponseHelper::error('Email and password are required', 400);
        }

        $user = ORMHelper::select(User::class)
            ->where('email', $email)
            ->fetchOne();

        if (!$user || !password_verify($password, $user->password)) {
            ResponseHelper::error('Invalid credentials', 401);
        }

        $credentials = [
            'user_id' => $user->id,
            'email' => $user->email,
            'name' => $user->name,
            'role' => $user->role
        ];

        AuthHelper::setup($credentials, false);

        ResponseHelper::success([
            'message' => 'Login successful',
            'user' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'role' => $user->role
            ]
        ]);
    }
}


