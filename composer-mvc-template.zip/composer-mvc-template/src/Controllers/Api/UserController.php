<?php

namespace Source\Controllers\Api;

use Core\Helpers\ORMHelper;
use Core\Helpers\ResponseHelper;
use Source\Models\User;

class UserController
{
    public function index()
    {
        $users = ORMHelper::select(User::class)
            ->fetchAll();

        ResponseHelper::success([
            'users' => array_map(function ($user) {
                return [
                    'id' => $user->id,
                    'name' => $user->name,
                    'email' => $user->email,
                    'role' => $user->role,
                    'created_at' => $user->createdAt->format('Y-m-d H:i:s')
                ];
            }, $users)
        ]);
    }

    public function show($id)
    {
        $user = ORMHelper::select(User::class)
            ->where('id', $id)
            ->fetchOne();

        if (!$user) {
            ResponseHelper::error('User not found', 404);
        }

        ResponseHelper::success([
            'user' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'role' => $user->role,
                'created_at' => $user->createdAt->format('Y-m-d H:i:s')
            ]
        ]);
    }
}


