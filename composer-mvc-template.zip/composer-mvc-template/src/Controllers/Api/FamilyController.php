<?php

namespace Source\Controllers\Api;

use Core\Helpers\ResponseHelper;
use Core\Helpers\MockDataHelper;

class FamilyController
{
    private function getRoomTypeConfig(string $type): array
    {
        // Mock de capacidades por tipo de quarto
        $map = [
            'single' => [
                'max_capacity' => 2,
                'max_children' => 1,
                'extra_bed_capacity' => 0,
                'family_friendly' => false,
                'interconnecting_available' => false
            ],
            'double' => [
                'max_capacity' => 3,
                'max_children' => 2,
                'extra_bed_capacity' => 1,
                'family_friendly' => true,
                'interconnecting_available' => false
            ],
            'suite' => [
                'max_capacity' => 4,
                'max_children' => 3,
                'extra_bed_capacity' => 2,
                'family_friendly' => true,
                'interconnecting_available' => true
            ],
            'deluxe' => [
                'max_capacity' => 5,
                'max_children' => 3,
                'extra_bed_capacity' => 2,
                'family_friendly' => true,
                'interconnecting_available' => true
            ]
        ];
        return $map[$type] ?? $map['double'];
    }

    private function readJson(): array
    {
        $raw = file_get_contents('php://input');
        $data = json_decode($raw, true);
        return is_array($data) ? $data : [];
    }

    // POST /api/check-capacity
    public function checkCapacity()
    {
        $body = $this->readJson();
        $type = $body['room_type'] ?? 'double';
        $adults = (int) ($body['adults'] ?? 1);
        $childrenAges = $body['children_ages'] ?? [];
        $children = is_array($childrenAges) ? count($childrenAges) : (int) ($body['children'] ?? 0);
        $total = $adults + $children;

        $cfg = $this->getRoomTypeConfig($type);

        // Políticas de idade
        $infants = array_values(array_filter($childrenAges, fn($a) => $a <= 2));
        $kids = array_values(array_filter($childrenAges, fn($a) => $a >= 3 && $a <= 12));
        $teens = array_values(array_filter($childrenAges, fn($a) => $a >= 13));

        $exceedsCapacity = $total > $cfg['max_capacity'];
        $exceedsChildren = $children > $cfg['max_children'];

        $needsExtraBeds = false;
        $extraBeds = 0;

        if (!$exceedsCapacity && $children > 0) {
            // Regra simples: 2 crianças (3-12) podem exigir 1 extra bed
            if (count($kids) >= 2) {
                $needsExtraBeds = true;
                $extraBeds = 1;
            }
        }

        $okWithExtra = ($total <= ($cfg['max_capacity'] + $cfg['extra_bed_capacity'])) && ($extraBeds <= $cfg['extra_bed_capacity']);

        ResponseHelper::success([
            'valid' => !$exceedsCapacity && !$exceedsChildren,
            'summary' => [
                'total_guests' => $total,
                'children_count' => $children,
                'infants' => count($infants),
                'kids' => count($kids),
                'teens' => count($teens)
            ],
            'policy' => $cfg,
            'exceeds_capacity' => $exceedsCapacity,
            'exceeds_children' => $exceedsChildren,
            'needs_extra_beds' => $needsExtraBeds,
            'extra_beds_count' => $extraBeds,
            'ok_with_extra' => $okWithExtra
        ]);
    }

    // GET /api/family-suggestions/{roomTypeId}
    public function familySuggestions($roomType)
    {
        // Sugere tipos alternativos por ordem
        $alternatives = ['suite','deluxe'];
        if ($roomType === 'single') { $alternatives = ['double','suite','deluxe']; }
        if ($roomType === 'double') { $alternatives = ['suite','deluxe']; }

        // Mock de disponibilidade: devolve quartos mockados do tipo selecionado
        $rooms = array_values(array_filter(MockDataHelper::getRooms(), function($r) use ($alternatives) {
            return in_array($r['type'], $alternatives) && $r['status'] === 'available';
        }));

        ResponseHelper::success([
            'alternatives' => $alternatives,
            'available_rooms' => $rooms
        ]);
    }

    // POST /api/calculate-extra-charges
    public function calculateExtraCharges()
    {
        $body = $this->readJson();
        $nights = (int) ($body['nights'] ?? 1);
        $extraBeds = (int) ($body['extra_beds'] ?? 0);
        $cribs = (int) ($body['cribs'] ?? 0);

        // Mock de preços de serviços
        $prices = [
            'extra_bed_per_night' => 20.0,
            'crib_per_stay' => 15.0
        ];

        $extra = ($extraBeds * $nights * $prices['extra_bed_per_night']) + ($cribs * $prices['crib_per_stay']);

        ResponseHelper::success([
            'extra_total' => $extra,
            'breakdown' => [
                'extra_beds' => $extraBeds * $nights * $prices['extra_bed_per_night'],
                'cribs' => $cribs * $prices['crib_per_stay']
            ],
            'prices' => $prices
        ]);
    }

    // PUT /api/setup-family-room/{reservationId}
    public function setupFamilyRoom($reservationId)
    {
        // Apenas confirma recebimento no mock
        $body = $this->readJson();
        // Aqui notificaríamos housekeeping/restaurante/receção
        ResponseHelper::success([
            'reservation_id' => $reservationId,
            'configured' => true,
            'configuration' => $body
        ]);
    }
}


