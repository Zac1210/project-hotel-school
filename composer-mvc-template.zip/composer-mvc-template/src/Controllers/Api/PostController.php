<?php

namespace Source\Controllers\Api;

use Core\Helpers\ORMHelper;
use Core\Helpers\ResponseHelper;
use Source\Models\Post;

class PostController
{
    public function index()
    {
        $posts = ORMHelper::select(Post::class)
            ->fetchAll();

        ResponseHelper::success([
            'posts' => array_map(function ($post) {
                return [
                    'id' => $post->id,
                    'title' => $post->title,
                    'content' => $post->content,
                    'user_id' => $post->user->id ?? null,
                    'created_at' => $post->createdAt->format('Y-m-d H:i:s'),
                    'updated_at' => $post->updatedAt->format('Y-m-d H:i:s')
                ];
            }, $posts)
        ]);
    }

    public function show($id)
    {
        $post = ORMHelper::select(Post::class)
            ->where('id', $id)
            ->fetchOne();

        if (!$post) {
            ResponseHelper::error('Post not found', 404);
        }

        ResponseHelper::success([
            'post' => [
                'id' => $post->id,
                'title' => $post->title,
                'content' => $post->content,
                'user_id' => $post->user->id ?? null,
                'created_at' => $post->createdAt->format('Y-m-d H:i:s'),
                'updated_at' => $post->updatedAt->format('Y-m-d H:i:s')
            ]
        ]);
    }
}


