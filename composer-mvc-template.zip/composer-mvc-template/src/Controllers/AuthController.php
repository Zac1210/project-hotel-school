<?php

namespace Source\Controllers;

use Core\Helpers\AuthHelper;
use Core\Helpers\ResponseHelper;
use Core\View;

class AuthController
{
    public function showAuth()
    {
        if (AuthHelper::check()) {
            header('Location: /dashboard');
            exit;
        }

        View::render('auth/login', [
            'title' => 'Login - Hotel-Moz',
            'csrf_token' => AuthHelper::csrfToken()
        ]);
    }

    public function login()
    {
        if (!AuthHelper::validateCsrf($_POST['csrf_token'] ?? '')) {
            ResponseHelper::error('Invalid CSRF token', 419);
        }

        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';
        $remember = isset($_POST['remember']);

        // Autenticação mockada apenas para desenvolvimento do frontend
        // Credencial do admin: admin@hotelmoz.com / admin123
        $mockUsers = [
            'admin@hotelmoz.com' => [
                'id' => 1,
                'email' => 'admin@hotelmoz.com',
                'name' => 'Administrador',
                'role' => 'admin',
                'password' => 'admin123' // Em produção, isso seria um hash
            ]
        ];

        // Verificar credenciais mockadas
        if (!isset($mockUsers[$email]) || $mockUsers[$email]['password'] !== $password) {
            ResponseHelper::error('Invalid credentials', 401);
        }

        $user = $mockUsers[$email];
        $credentials = [
            'user_id' => $user['id'],
            'email' => $user['email'],
            'name' => $user['name'],
            'role' => $user['role']
        ];

        AuthHelper::setup($credentials, $remember);

        // Redirecionar admin direto para dashboard admin
        $redirect = '/dashboard';
        if ($user['role'] === 'admin') {
            $redirect = '/dashboard/admin';
        } elseif (in_array($user['role'], ['receptionist', 'manager'])) {
            $redirect = '/dashboard/' . $user['role'];
        }

        ResponseHelper::success([
            'message' => 'Login successful',
            'redirect' => $_POST['redirect'] ?? $redirect
        ]);
    }

    public function register()
    {
        if (!AuthHelper::validateCsrf($_POST['csrf_token'] ?? '')) {
            ResponseHelper::error('Invalid CSRF token', 419);
        }

        $name = $_POST['name'] ?? '';
        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';
        $remember = isset($_POST['remember']);

        // Registro mockado apenas para desenvolvimento do frontend
        // Não salva no banco, apenas simula o registro
        // Em produção, isso seria salvo no banco de dados
        
        // Simular criação de usuário (mockado)
        $userId = time(); // ID temporário baseado no timestamp

        $credentials = [
            'user_id' => $userId,
            'email' => $email,
            'name' => $name,
            'role' => 'client' // Cliente padrão para novos usuários
        ];

        AuthHelper::setup($credentials, $remember);

        ResponseHelper::success([
            'message' => 'Registration successful',
            'redirect' => '/dashboard'
        ], 201);
    }

    public function logout()
    {
        AuthHelper::logout();
        header('Location: /auth');
        exit;
    }
}