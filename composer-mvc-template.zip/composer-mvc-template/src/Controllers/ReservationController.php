<?php

namespace Source\Controllers;

use Core\View;
use Core\Helpers\AuthHelper;
use Core\Helpers\MockDataHelper;
use Core\Helpers\ResponseHelper;

class ReservationController
{
    public function index()
    {
        // Modo desenvolvimento frontend: permite acesso sem autenticação
        $credentials = AuthHelper::check();
        if (!$credentials) {
            $credentials = [
                'user_id' => 999,
                'email' => 'cliente@example.com',
                'name' => 'Cliente Teste',
                'role' => 'client'
            ];
        }

        // Dados mockados
        $reservations = MockDataHelper::getReservations();

        View::render('reservations/index', [
            'title' => 'Minhas Reservas',
            'user' => $credentials,
            'reservations' => $reservations
        ]);
    }

    public function create()
    {
        // Modo desenvolvimento frontend: permite acesso sem autenticação
        $credentials = AuthHelper::check();
        if (!$credentials) {
            $credentials = [
                'user_id' => 999,
                'email' => 'cliente@example.com',
                'name' => 'Cliente Teste',
                'role' => 'client'
            ];
        }

        $roomId = (int) ($_GET['room_id'] ?? 0);
        $checkIn = $_GET['check_in'] ?? '';
        $checkOut = $_GET['check_out'] ?? '';
        $adults = (int) ($_GET['adults'] ?? 1);
        $children = (int) ($_GET['children'] ?? 0);

        // Dados mockados
        $room = $roomId ? MockDataHelper::getRoom($roomId) : null;

        View::render('reservations/create', [
            'title' => 'Nova Reserva',
            'user' => $credentials,
            'room' => $room,
            'check_in' => $checkIn,
            'check_out' => $checkOut,
            'adults' => $adults,
            'children' => $children,
            'csrf_token' => AuthHelper::csrfToken()
        ]);
    }

    public function store()
    {
        $credentials = AuthHelper::check();
        if (!$credentials) {
            ResponseHelper::error('Unauthorized', 401);
        }

        if (!AuthHelper::validateCsrf($_POST['csrf_token'] ?? '')) {
            ResponseHelper::error('Invalid CSRF token', 419);
        }

        $roomId = (int) ($_POST['room_id'] ?? 0);
        $checkIn = $_POST['check_in'] ?? '';
        $checkOut = $_POST['check_out'] ?? '';
        $adults = (int) ($_POST['adults'] ?? 1);
        $children = (int) ($_POST['children'] ?? 0);
        $specialRequests = $_POST['special_requests'] ?? '';

        if (empty($checkIn) || empty($checkOut) || $roomId === 0) {
            ResponseHelper::error('Dados incompletos', 400);
        }

        // Dados mockados
        $room = MockDataHelper::getRoom($roomId);

        if (!$room || $room['status'] !== 'available') {
            ResponseHelper::error('Quarto não disponível', 400);
        }

        $checkInDate = new \DateTime($checkIn);
        $checkOutDate = new \DateTime($checkOut);
        $nights = $checkInDate->diff($checkOutDate)->days;

        // Regra de negócio: máximo de 2 noites online
        if ($nights > 2) {
            ResponseHelper::error('Reservas online acima de 2 noites exigem presença na recepção. Por favor, contacte a recepção.', 422);
        }

        $totalPrice = $room['price_per_night'] * $nights;

        // Simular criação de reserva (dados mockados)
        $reservationId = count(MockDataHelper::getReservations()) + 1;

        ResponseHelper::success([
            'message' => 'Reserva criada com sucesso!',
            'redirect' => '/reservations/' . $reservationId
        ], 201);
    }

    public function show($id)
    {
        // Modo desenvolvimento frontend: permite acesso sem autenticação
        $credentials = AuthHelper::check();
        if (!$credentials) {
            $credentials = [
                'user_id' => 999,
                'email' => 'cliente@example.com',
                'name' => 'Cliente Teste',
                'role' => 'client'
            ];
        }

        // Dados mockados
        $reservation = MockDataHelper::getReservation($id);

        if (!$reservation) {
            http_response_code(404);
            View::render('404', [
                'title' => 'Reserva Não Encontrada',
                'message' => 'A reserva que você está procurando não existe ou você não tem permissão para visualizá-la.'
            ]);
            return;
        }
        
        // Converter array para objeto, mantendo estrutura compatível
        $reservationObj = (object) [
            'id' => $reservation['id'],
            'reservation_code' => $reservation['reservation_code'],
            'check_in' => new \DateTime($reservation['check_in']),
            'check_out' => new \DateTime($reservation['check_out']),
            'adults' => $reservation['adults'],
            'children' => $reservation['children'],
            'total_price' => $reservation['total_price'],
            'status' => $reservation['status'],
            'special_requests' => $reservation['special_requests'] ?? null,
            'client' => (object) $reservation['client'],
            'room' => (object) $reservation['room']
        ];
        $reservation = $reservationObj;

        View::render('reservations/show', [
            'title' => 'Detalhes da Reserva',
            'user' => $credentials,
            'reservation' => $reservation
        ]);
    }
}

