<?php

namespace Source\Controllers;

use Core\View;
use Core\Helpers\AuthHelper;
use Core\Helpers\ResponseHelper;
use Core\Helpers\MockDataHelper;

class RoomController
{
    public function index()
    {
        $credentials = AuthHelper::check();

        // Opções de filtros
        $types = ['Todos', 'single' => 'Standard', 'double' => 'Familiar', 'suite' => 'Suíte', 'deluxe' => 'Deluxe'];
        $amenities = ['WiFi','Ar Condicionado','TV','Frigobar','Varanda','Vista'];

        // Dados mockados dos quartos
        $rooms = MockDataHelper::getRooms();

        View::render('hotel/rooms', [
            'title' => 'Quartos',
            'user_logged_in' => $credentials !== null,
            'types' => $types,
            'amenities' => $amenities,
            'rooms' => $rooms
        ]);
    }

    public function show($id)
    {
        $room = MockDataHelper::getRoom($id);
        if (!$room) {
            ResponseHelper::error('Quarto não encontrado', 404);
        }
        ResponseHelper::success(['room' => $room]);
    }

    public function checkAvailability()
    {
        $roomId = (int) ($_GET['room_id'] ?? 0);
        $checkIn = $_GET['check_in'] ?? '';
        $checkOut = $_GET['check_out'] ?? '';

        if (!$roomId || empty($checkIn) || empty($checkOut)) {
            ResponseHelper::error('Parâmetros inválidos', 400);
        }

        $room = MockDataHelper::getRoom($roomId);
        if (!$room) {
            ResponseHelper::error('Quarto não encontrado', 404);
        }

        // Mock: quartos com status 'available' estão disponíveis
        $available = $room['status'] === 'available';
        ResponseHelper::success(['available' => $available]);
    }

    public function getFilterOptions()
    {
        $types = ['Standard','Familiar','Suíte','Deluxe'];
        $amenities = ['WiFi','Ar Condicionado','TV','Frigobar','Varanda','Vista'];
        ResponseHelper::success([
            'types' => $types,
            'amenities' => $amenities
        ]);
    }
}


