<?php
ob_start();
?>
<div class="min-h-screen py-12">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 class="text-3xl font-bold mb-8">Quartos Disponíveis</h1>
        
        <div class="bg-white p-4 rounded-lg shadow mb-6">
            <p class="text-gray-700">
                <strong>Check-in:</strong> <?= htmlspecialchars($check_in ?? '') ?> | 
                <strong>Check-out:</strong> <?= htmlspecialchars($check_out ?? '') ?> | 
                <strong>Adultos:</strong> <?= htmlspecialchars($adults ?? 1) ?> | 
                <strong>Crianças:</strong> <?= htmlspecialchars($children ?? 0) ?> |
                <strong>Noites:</strong> <?= htmlspecialchars($nights ?? 1) ?>
            </p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php if (empty($rooms)): ?>
                <div class="col-span-full text-center py-12">
                    <p class="text-gray-600 text-lg">Nenhum quarto disponível para estas datas.</p>
                    <a href="/" class="mt-4 inline-block bg-blue-600 text-white px-6 py-3 rounded hover:bg-blue-700">
                        Buscar Novamente
                    </a>
                </div>
            <?php else: ?>
                <?php foreach ($rooms as $room): ?>
                    <?php 
                    // Converter array para objeto se necessário
                    $room = is_array($room) ? (object) $room : $room;
                    $cover = isset($room->images[0]) ? $room->images[0] : 'https://images.unsplash.com/photo-1505692794403-34d4982f88aa?q=80&w=1200&auto=format&fit=crop';
                    ?>
                    <div class="bg-white rounded-lg shadow-lg overflow-hidden">
                        <div class="h-48 bg-gray-200 overflow-hidden">
                            <img src="<?= htmlspecialchars($cover) ?>" alt="Quarto" class="w-full h-full object-cover">
                        </div>
                        <div class="p-6">
                            <div class="flex justify-between items-start mb-2">
                                <h3 class="text-xl font-bold">Quarto <?= htmlspecialchars($room->number ?? $room['number'] ?? 'N/A') ?></h3>
                                <span class="bg-green-100 text-green-800 px-2 py-1 rounded text-sm">Disponível</span>
                            </div>
                            <p class="text-gray-600 mb-2"><?= htmlspecialchars(ucfirst($room->type ?? $room['type'] ?? 'standard')) ?> - Andar <?= htmlspecialchars($room->floor ?? $room['floor'] ?? '1') ?></p>
                            <p class="text-gray-700 mb-4"><?= htmlspecialchars($room->description ?? $room['description'] ?? 'Quarto confortável e bem equipado') ?></p>
                            <div class="flex justify-between items-center">
                                <div>
                                    <p class="text-2xl font-bold text-blue-600">R$ <?= number_format($room->price_per_night ?? $room['price_per_night'] ?? 0, 2, ',', '.') ?></p>
                                    <p class="text-sm text-gray-500">por noite</p>
                                </div>
                                <a href="/reservations/create?room_id=<?= $room->id ?? $room['id'] ?>&check_in=<?= htmlspecialchars($check_in) ?>&check_out=<?= htmlspecialchars($check_out) ?>&adults=<?= htmlspecialchars($adults) ?>&children=<?= htmlspecialchars($children) ?>" 
                                   class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                                    Reservar
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php
$content = ob_get_clean();
$show_navbar = true;
$show_footer = true;
require_once __DIR__ . '/../layouts/hotel.php';
?>

