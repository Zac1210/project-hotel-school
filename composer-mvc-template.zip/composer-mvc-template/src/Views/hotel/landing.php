<?php
ob_start();
?>
<div class="min-h-screen">
    <!-- Menu de Navegação Rápida -->
    <section class="bg-white shadow-md sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div class="flex flex-wrap items-center justify-between">
                <div class="flex items-center space-x-8">
                    <h2 class="text-xl font-bold text-blue-600">Menu de Navegação</h2>
                    <nav class="flex space-x-4">
                        <a href="/auth" class="text-gray-700 hover:text-blue-600 font-medium">Login</a>
                        <a href="/dashboard/admin" class="text-gray-700 hover:text-blue-600 font-medium">Dashboard Admin</a>
                        <a href="/dashboard/client" class="text-gray-700 hover:text-blue-600 font-medium">Dashboard Cliente</a>
                        <a href="/dashboard/receptionist" class="text-gray-700 hover:text-blue-600 font-medium">Dashboard Recepção</a>
                        <a href="/dashboard/housekeeper" class="text-gray-700 hover:text-blue-600 font-medium">Dashboard Limpeza</a>
                        <a href="/dashboard/manager" class="text-gray-700 hover:text-blue-600 font-medium">Dashboard Gerente</a>
                        <a href="/reservations" class="text-gray-700 hover:text-blue-600 font-medium">Reservas</a>
                        <a href="/reservations/create" class="text-gray-700 hover:text-blue-600 font-medium">Nova Reserva</a>
                    </nav>
                </div>
            </div>
        </div>
    </section>

    <!-- Hero Section com Carrossel de Imagens -->
    <section class="relative h-screen overflow-hidden">
        <!-- Carrossel de Imagens -->
        <div class="hero-slider absolute inset-0">
            <!-- Imagem 1 - Recepção/Lobby -->
            <div class="hero-slide absolute inset-0 bg-cover bg-center transition-opacity duration-1000 ease-in-out opacity-100" 
                 style="background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('https://images.unsplash.com/photo-1566073771259-6a8506099945?w=1920');">
            </div>
            
            <!-- Imagem 2 - Quarto Luxuoso -->
            <div class="hero-slide absolute inset-0 bg-cover bg-center transition-opacity duration-1000 ease-in-out opacity-0" 
                 style="background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('https://images.unsplash.com/photo-1611892440504-42a792e24d32?w=1920');">
            </div>
            
            <!-- Imagem 3 - Piscina -->
            <div class="hero-slide absolute inset-0 bg-cover bg-center transition-opacity duration-1000 ease-in-out opacity-0" 
                 style="background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('https://images.unsplash.com/photo-1540541338287-41700207dee6?w=1920');">
            </div>
            
            <!-- Imagem 4 - Restaurante -->
            <div class="hero-slide absolute inset-0 bg-cover bg-center transition-opacity duration-1000 ease-in-out opacity-0" 
                 style="background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=1920');">
            </div>
            
            <!-- Imagem 5 - Vista Panorâmica -->
            <div class="hero-slide absolute inset-0 bg-cover bg-center transition-opacity duration-1000 ease-in-out opacity-0" 
                 style="background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('https://images.unsplash.com/photo-1564501049412-61c2a3083791?w=1920');">
            </div>
            
            <!-- Imagem 6 - Spa/Bem-estar -->
            <div class="hero-slide absolute inset-0 bg-cover bg-center transition-opacity duration-1000 ease-in-out opacity-0" 
                 style="background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=1920');">
            </div>
        </div>

        <!-- Conteúdo sobre as imagens -->
        <div class="relative z-10 h-full flex items-center justify-center">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
                <!-- Títulos que mudam com as imagens -->
                <div class="hero-content">
                    <h1 class="hero-title text-5xl md:text-6xl font-bold mb-4 transition-all duration-500">Sua Experiência Inesquecível Começa Aqui</h1>
                    <p class="hero-subtitle text-xl md:text-2xl mb-8 transition-all duration-500">Hotel 5 estrelas com conforto e atendimento exclusivo</p>
                </div>
            
            <!-- Buscador de Reservas -->
            <div class="bg-white rounded-lg shadow-2xl p-6 max-w-4xl mx-auto mt-8">
                <form action="/search" method="GET" class="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div>
                        <label class="block text-gray-700 text-sm font-bold mb-2">Data Entrada</label>
                        <input type="date" name="check_in" required class="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:border-blue-500 text-gray-900">
                    </div>
                    <div>
                        <label class="block text-gray-700 text-sm font-bold mb-2">Data Saída</label>
                        <input type="date" name="check_out" required class="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:border-blue-500 text-gray-900">
                    </div>
                    <div>
                        <label class="block text-gray-700 text-sm font-bold mb-2">Adultos</label>
                        <input type="number" name="adults" min="1" value="1" class="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:border-blue-500 text-gray-900">
                    </div>
                    <div>
                        <label class="block text-gray-700 text-sm font-bold mb-2">Crianças</label>
                        <input type="number" name="children" min="0" value="0" class="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:border-blue-500 text-gray-900">
                    </div>
                    <div class="md:col-span-4">
                        <button type="submit" class="w-full bg-blue-600 text-white py-3 px-6 rounded-lg hover:bg-blue-700 font-semibold text-lg">
                            Ver Disponibilidade
                        </button>
                    </div>
                </form>
            </div>

            <!-- Elementos de Confiança -->
            <div class="mt-8 flex justify-center items-center space-x-8">
                <div class="text-center">
                    <div class="text-3xl font-bold text-yellow-400">★★★★★</div>
                    <div class="text-sm mt-2">Avaliação 5 Estrelas</div>
                </div>
                <div class="text-center">
                    <div class="text-2xl font-bold">1000+</div>
                    <div class="text-sm mt-2">Clientes Satisfeitos</div>
                </div>
            </div>
            </div>
        </div>

        <!-- Indicadores de slide -->
        <div class="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-20 flex space-x-3">
            <button class="hero-indicator w-3 h-3 rounded-full bg-white opacity-100 transition-opacity duration-300" data-slide="0"></button>
            <button class="hero-indicator w-3 h-3 rounded-full bg-white opacity-50 transition-opacity duration-300" data-slide="1"></button>
            <button class="hero-indicator w-3 h-3 rounded-full bg-white opacity-50 transition-opacity duration-300" data-slide="2"></button>
            <button class="hero-indicator w-3 h-3 rounded-full bg-white opacity-50 transition-opacity duration-300" data-slide="3"></button>
            <button class="hero-indicator w-3 h-3 rounded-full bg-white opacity-50 transition-opacity duration-300" data-slide="4"></button>
            <button class="hero-indicator w-3 h-3 rounded-full bg-white opacity-50 transition-opacity duration-300" data-slide="5"></button>
        </div>
    </section>

    <!-- Diferenciais -->
    <section class="py-16 bg-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 class="text-3xl font-bold text-center mb-12">Nossos Diferenciais</h2>
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
                <div class="text-center">
                    <div class="text-4xl mb-4">📶</div>
                    <h3 class="text-xl font-semibold mb-2">WiFi Grátis</h3>
                    <p class="text-gray-600">Internet de alta velocidade em todo o hotel</p>
                </div>
                <div class="text-center">
                    <div class="text-4xl mb-4">💆</div>
                    <h3 class="text-xl font-semibold mb-2">Spa & Bem-estar</h3>
                    <p class="text-gray-600">Relaxe em nosso spa completo</p>
                </div>
                <div class="text-center">
                    <div class="text-4xl mb-4">🏊</div>
                    <h3 class="text-xl font-semibold mb-2">Piscina</h3>
                    <p class="text-gray-600">Piscina climatizada com vista panorâmica</p>
                </div>
                <div class="text-center">
                    <div class="text-4xl mb-4">🍽️</div>
                    <h3 class="text-xl font-semibold mb-2">Restaurante</h3>
                    <p class="text-gray-600">Culinária internacional premiada</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Depoimentos -->
    <section class="py-16 bg-gray-100">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 class="text-3xl font-bold text-center mb-12">O Que Nossos Clientes Dizem</h2>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div class="bg-white p-6 rounded-lg shadow">
                    <div class="text-yellow-400 mb-2">★★★★★</div>
                    <p class="text-gray-700 mb-4">"Experiência incrível! Atendimento impecável e quartos luxuosos."</p>
                    <p class="font-semibold">- Maria Silva</p>
                </div>
                <div class="bg-white p-6 rounded-lg shadow">
                    <div class="text-yellow-400 mb-2">★★★★★</div>
                    <p class="text-gray-700 mb-4">"O melhor hotel que já fiquei! Super recomendo."</p>
                    <p class="font-semibold">- João Santos</p>
                </div>
                <div class="bg-white p-6 rounded-lg shadow">
                    <div class="text-yellow-400 mb-2">★★★★★</div>
                    <p class="text-gray-700 mb-4">"Excelente localização e todas as comodidades que você precisa."</p>
                    <p class="font-semibold">- Ana Costa</p>
                </div>
            </div>
        </div>
    </section>
</div>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const slides = document.querySelectorAll('.hero-slide');
    const indicators = document.querySelectorAll('.hero-indicator');
    const titles = [
        { main: 'Sua Experiência Inesquecível Começa Aqui', sub: 'Hotel 5 estrelas com conforto e atendimento exclusivo' },
        { main: 'Quartos Luxuosos e Confortáveis', sub: 'Descanse em acomodações de primeira classe' },
        { main: 'Piscina com Vista Panorâmica', sub: 'Relaxe com uma vista deslumbrante' },
        { main: 'Gastronomia de Primeira', sub: 'Saboreie pratos excepcionais em nosso restaurante' },
        { main: 'Vistas Incríveis da Cidade', sub: 'Desfrute de paisagens espetaculares' },
        { main: 'Spa e Bem-estar Completo', sub: 'Renove sua energia em nosso spa exclusivo' }
    ];
    
    let currentSlide = 0;
    const totalSlides = slides.length;
    
    // Função para mudar slide
    function changeSlide(index) {
        // Remove classe ativa de todos os slides
        slides.forEach((slide, i) => {
            if (i === index) {
                slide.classList.remove('opacity-0');
                slide.classList.add('opacity-100');
            } else {
                slide.classList.remove('opacity-100');
                slide.classList.add('opacity-0');
            }
        });
        
        // Atualiza indicadores
        indicators.forEach((indicator, i) => {
            if (i === index) {
                indicator.classList.remove('opacity-50');
                indicator.classList.add('opacity-100');
            } else {
                indicator.classList.remove('opacity-100');
                indicator.classList.add('opacity-50');
            }
        });
        
        // Atualiza títulos
        const heroTitle = document.querySelector('.hero-title');
        const heroSubtitle = document.querySelector('.hero-subtitle');
        if (heroTitle && heroSubtitle) {
            heroTitle.style.opacity = '0';
            heroSubtitle.style.opacity = '0';
            
            setTimeout(() => {
                heroTitle.textContent = titles[index].main;
                heroSubtitle.textContent = titles[index].sub;
                heroTitle.style.opacity = '1';
                heroSubtitle.style.opacity = '1';
            }, 300);
        }
    }
    
    // Auto-play: muda slide a cada 20 segundos
    function nextSlide() {
        currentSlide = (currentSlide + 1) % totalSlides;
        changeSlide(currentSlide);
    }
    
    // Inicia o carrossel automático
    setInterval(nextSlide, 20000); // 20 segundos
    
    // Adiciona evento de clique nos indicadores
    indicators.forEach((indicator, index) => {
        indicator.addEventListener('click', () => {
            currentSlide = index;
            changeSlide(currentSlide);
            // Reinicia o timer ao clicar manualmente
            clearInterval(window.heroInterval);
            window.heroInterval = setInterval(nextSlide, 20000);
        });
    });
    
    // Adiciona navegação com setas do teclado
    document.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowLeft') {
            currentSlide = (currentSlide - 1 + totalSlides) % totalSlides;
            changeSlide(currentSlide);
            clearInterval(window.heroInterval);
            window.heroInterval = setInterval(nextSlide, 20000);
        } else if (e.key === 'ArrowRight') {
            currentSlide = (currentSlide + 1) % totalSlides;
            changeSlide(currentSlide);
            clearInterval(window.heroInterval);
            window.heroInterval = setInterval(nextSlide, 20000);
        }
    });
    
    // Inicializa o intervalo
    window.heroInterval = setInterval(nextSlide, 20000);
});
</script>

<?php
$content = ob_get_clean();
$show_navbar = true;
$show_footer = true;
require_once __DIR__ . '/../layouts/hotel.php';
?>

