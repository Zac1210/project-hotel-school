<?php
ob_start();
?>
<div class="min-h-screen py-10">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex flex-col md:flex-row md:items-end md:justify-between gap-4 mb-6">
            <h1 class="text-3xl font-bold">Quartos</h1>
            <div class="text-gray-600" id="rooms-count">0 quartos encontrados</div>
        </div>

        <!-- Filtros -->
        <div class="bg-white rounded-lg shadow p-4 md:p-6 mb-6">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                <!-- Tipo -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Tipo</label>
                    <select id="filter-type" class="w-full border-gray-300 rounded-lg">
                        <option value="">Todos</option>
                        <option value="suite">Suíte</option>
                        <option value="single">Standard</option>
                        <option value="double">Familiar</option>
                        <option value="deluxe">Deluxe</option>
                    </select>
                </div>

                <!-- Preço -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Preço por noite</label>
                    <div class="flex items-center space-x-3">
                        <input id="filter-price-min" type="number" min="0" class="w-28 border-gray-300 rounded-lg" placeholder="Min">
                        <span class="text-gray-400">—</span>
                        <input id="filter-price-max" type="number" min="0" class="w-28 border-gray-300 rounded-lg" placeholder="Max">
                    </div>
                </div>

                <!-- Comodidades -->
                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Comodidades</label>
                    <div id="filter-amenities" class="flex flex-wrap gap-2">
                        <?php foreach ($amenities as $amenity): ?>
                            <label class="inline-flex items-center space-x-2 bg-gray-50 border border-gray-200 rounded-full px-3 py-1 text-sm">
                                <input type="checkbox" value="<?= htmlspecialchars($amenity) ?>" class="amenity">
                                <span><?= htmlspecialchars($amenity) ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <div class="mt-4 flex items-center gap-3">
                <button id="apply-filters" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">Aplicar Filtros</button>
                <button id="clear-filters" class="px-4 py-2 rounded-lg border border-gray-300 hover:bg-gray-50">Limpar Filtros</button>
                <div class="ml-auto">
                    <label class="mr-2 text-sm text-gray-600">Ordenar por</label>
                    <select id="sort-by" class="border-gray-300 rounded-lg">
                        <option value="price_asc">Preço: Menor para Maior</option>
                        <option value="price_desc">Preço: Maior para Menor</option>
                        <option value="popular">Mais Populares</option>
                        <option value="name_asc">Nome A-Z</option>
                        <option value="rating">Melhor Avaliados</option>
                    </select>
                </div>
            </div>
        </div>

        <!-- Grid de Cards -->
        <div id="rooms-grid" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"></div>

        <!-- Paginação -->
        <div class="flex items-center justify-between mt-8" id="pagination">
            <button id="prev-page" class="px-4 py-2 border rounded-lg hover:bg-gray-50">Anterior</button>
            <div id="page-info" class="text-gray-600"></div>
            <button id="next-page" class="px-4 py-2 border rounded-lg hover:bg-gray-50">Próxima</button>
        </div>
    </div>

    <!-- Modal Detalhes -->
    <div id="room-modal" class="fixed inset-0 bg-black/50 hidden items-center justify-center p-4">
        <div class="bg-white rounded-xl max-w-3xl w-full shadow-2xl overflow-hidden">
            <div class="flex justify-between items-center px-6 py-4 border-b">
                <h3 id="modal-title" class="text-xl font-semibold">Detalhes do Quarto</h3>
                <button id="modal-close" class="w-8 h-8 rounded-full hover:bg-gray-100 flex items-center justify-center">✕</button>
            </div>
            <div id="modal-content" class="p-6"></div>
        </div>
    </div>
</div>

<script id="rooms-json" type="application/json"><?= json_encode($rooms, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?></script>
<script src="/assets/js/rooms.js"></script>
<?php
$content = ob_get_clean();
$show_navbar = true;
$show_footer = true;
require_once __DIR__ . '/../layouts/hotel.php';
?>


