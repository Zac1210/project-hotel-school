<?php
ob_start();
?>
<style>
/* Glassmorphism util (para Tailwind CDN) */
.glass {
    background: rgba(255, 255, 255, 0.12);
    box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.18);
}
</style>

<div class="min-h-screen relative">
    <!-- Background com imagem de hotel -->
    <div class="absolute inset-0 bg-cover bg-center" style="background-image: linear-gradient(rgba(7, 16, 29, 0.55), rgba(7, 16, 29, 0.65)), url('https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?q=80&w=1920&auto=format&fit=crop');"></div>

    <!-- Navbar -->
    <nav class="relative z-10">
        <div class="max-w-7xl mx-auto px-6 py-5 flex items-center justify-between">
            <div class="text-white font-extrabold text-2xl">Hotel‑Moz</div>
            <ul class="hidden md:flex items-center space-x-8 text-white/90 font-medium">
                <li><a href="/" class="hover:text-white">Home</a></li>
                <li><a href="#" class="hover:text-white">About</a></li>
                <li><a href="#" class="hover:text-white">Services</a></li>
                <li><a href="#" class="hover:text-white">Contact</a></li>
            </ul>
            <a href="/auth" class="hidden md:inline-block border border-white/40 text-white px-5 py-2 rounded-lg hover:bg-white hover:text-gray-900 transition">Login</a>
        </div>
    </nav>

    <!-- Modal de Login -->
    <div class="relative z-10 min-h-[calc(100vh-80px)] flex items-center justify-center px-4 pb-12">
        <div class="glass rounded-2xl w-full max-w-lg text-white">
            <div class="p-6 flex justify-end">
                <button type="button" onclick="window.location.href='/'" aria-label="Fechar" class="w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center">✕</button>
            </div>
            <div class="px-8 pb-10 -mt-8">
                <h1 class="text-3xl font-extrabold text-center mb-8">Login</h1>
                <form id="loginForm" method="POST" action="/login" class="space-y-6">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token) ?>">

                    <div>
                        <label class="block text-sm mb-2">Email</label>
                        <div class="relative">
                            <input type="email" name="email" required autocomplete="email" placeholder="seu@email.com" class="w-full px-4 py-3 rounded-lg bg-white/10 placeholder-white/60 border border-white/20 focus:outline-none focus:ring-2 focus:ring-white/40">
                            <span class="absolute right-3 top-1/2 transform -translate-y-1/2 text-white/70">✉️</span>
                        </div>
                    </div>

                    <div>
                        <label class="block text-sm mb-2">Password</label>
                        <div class="relative">
                            <input id="login-password" type="password" name="password" required autocomplete="current-password" placeholder="••••••••" class="w-full px-4 py-3 rounded-lg bg-white/10 placeholder-white/60 border border-white/20 focus:outline-none focus:ring-2 focus:ring-white/40">
                            <span class="absolute right-3 top-1/2 transform -translate-y-1/2 text-white/70">🔒</span>
                        </div>
                    </div>

                    <div class="flex items-center justify-between text-sm">
                        <label class="inline-flex items-center space-x-2">
                            <input type="checkbox" name="remember" class="rounded bg-white/10 border-white/30">
                            <span>Remember me</span>
                        </label>
                        <a href="#" class="hover:underline">Forgot Password?</a>
                    </div>

                    <div id="login-error" class="hidden bg-red-500/15 border border-red-400/40 text-red-200 px-4 py-3 rounded-lg">
                        <p id="login-error-message"></p>
                    </div>

                    <button type="submit" id="login-submit" class="w-full bg-white text-gray-900 py-3 rounded-lg font-semibold hover:bg-gray-100 transition">
                        <span id="login-submit-text">Login</span>
                        <span id="login-submit-loading" class="hidden">Entrando...</span>
                    </button>

                    <p class="text-center text-white/80 text-sm">Don't have an account? <a href="#" class="underline">Register</a></p>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
// Submit do formulário de login
document.getElementById('loginForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const submitBtn = document.getElementById('login-submit');
    const submitText = document.getElementById('login-submit-text');
    const submitLoading = document.getElementById('login-submit-loading');
    const errorDiv = document.getElementById('login-error');
    const errorMsg = document.getElementById('login-error-message');
    submitBtn.disabled = true;
    submitText.classList.add('hidden');
    submitLoading.classList.remove('hidden');
    errorDiv.classList.add('hidden');
    const formData = new FormData(this);
    try {
        const response = await fetch('/login', { method: 'POST', body: formData });
        const data = await response.json();
        if (data.success) {
            window.location.href = data.data.redirect || '/dashboard';
        } else {
            errorMsg.textContent = data.error || 'Erro ao fazer login';
            errorDiv.classList.remove('hidden');
        }
    } catch (error) {
        errorMsg.textContent = 'Erro de conexão. Tente novamente.';
        errorDiv.classList.remove('hidden');
    } finally {
        submitBtn.disabled = false;
        submitText.classList.remove('hidden');
        submitLoading.classList.add('hidden');
    }
});
</script>
<?php
$content = ob_get_clean();
$show_navbar = false;
$show_footer = false;
require_once __DIR__ . '/../layouts/hotel.php';
?>

