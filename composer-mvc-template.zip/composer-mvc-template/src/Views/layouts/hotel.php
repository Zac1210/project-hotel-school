<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($title ?? 'Hotel-Moz') ?> - Sistema de Gestão Hoteleira</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
    <?php if (isset($additional_css)): ?>
        <?= $additional_css ?>
    <?php endif; ?>
</head>
<body class="bg-gray-50">
    <?php if (isset($show_navbar) && $show_navbar): ?>
        <nav class="bg-white shadow-lg">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between h-16">
                    <div class="flex items-center">
                        <a href="/" class="text-2xl font-bold text-blue-600">Hotel-Moz</a>
                    </div>
                    <div class="flex items-center space-x-4">
                        <?php if (isset($user_logged_in) && $user_logged_in): ?>
                            <a href="/dashboard" class="text-gray-700 hover:text-blue-600">Dashboard</a>
                            <a href="/reservations" class="text-gray-700 hover:text-blue-600">Reservas</a>
                            <span class="text-gray-500"><?= htmlspecialchars($user['name'] ?? 'Usuário') ?></span>
                            <a href="/logout" class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600">Sair</a>
                        <?php else: ?>
                            <a href="/auth" class="text-gray-700 hover:text-blue-600">Login</a>
                            <a href="/auth" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Registrar</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </nav>
    <?php endif; ?>

    <main>
        <?= $content ?? '' ?>
    </main>

    <?php if (isset($show_footer) && $show_footer): ?>
        <footer class="bg-gray-800 text-white mt-12">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                <div class="text-center">
                    <p>&copy; <?= date('Y') ?> Hotel-Moz. Todos os direitos reservados.</p>
                </div>
            </div>
        </footer>
    <?php endif; ?>

    <?php if (isset($additional_js)): ?>
        <?= $additional_js ?>
    <?php endif; ?>
</body>
</html>


