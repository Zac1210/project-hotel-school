<?php
ob_start();
?>
<div class="min-h-screen py-8">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between items-center mb-8">
            <h1 class="text-3xl font-bold">Meu Painel</h1>
            <a href="/reservations/create" class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 font-semibold">
                Nova Reserva
            </a>
        </div>

        <!-- Cards de Reservas Ativas -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div class="bg-white p-6 rounded-lg shadow">
                <h3 class="text-lg font-semibold mb-2">Reservas Ativas</h3>
                <p class="text-3xl font-bold text-blue-600">
                    <?php 
                    $active = array_filter($reservations ?? [], function($r) {
                        $status = is_array($r) ? ($r['status'] ?? '') : ($r->status ?? '');
                        return in_array($status, ['confirmed', 'checked_in']);
                    });
                    echo count($active);
                    ?>
                </p>
            </div>
            <div class="bg-white p-6 rounded-lg shadow">
                <h3 class="text-lg font-semibold mb-2">Histórico</h3>
                <p class="text-3xl font-bold text-gray-600">
                    <?php 
                    $completed = array_filter($reservations ?? [], function($r) {
                        $status = is_array($r) ? ($r['status'] ?? '') : ($r->status ?? '');
                        return $status === 'checked_out';
                    });
                    echo count($completed);
                    ?>
                </p>
            </div>
            <div class="bg-white p-6 rounded-lg shadow">
                <h3 class="text-lg font-semibold mb-2">Total de Reservas</h3>
                <p class="text-3xl font-bold text-green-600"><?= count($reservations ?? []) ?></p>
            </div>
        </div>

        <!-- Lista de Reservas -->
        <div class="bg-white rounded-lg shadow overflow-hidden">
            <div class="px-6 py-4 border-b border-gray-200">
                <h2 class="text-xl font-semibold">Minhas Reservas</h2>
            </div>
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Código</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Quarto</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Check-in</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Check-out</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Valor</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Ações</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php if (empty($reservations)): ?>
                            <tr>
                                <td colspan="7" class="px-6 py-4 text-center text-gray-500">
                                    Nenhuma reserva encontrada. <a href="/reservations/create" class="text-blue-600 hover:underline">Faça sua primeira reserva!</a>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($reservations as $reservation): ?>
                                <?php
                                // Converter array para objeto se necessário
                                $reservation = is_array($reservation) ? (object) $reservation : $reservation;
                                $room = is_array($reservation->room ?? null) ? (object) ($reservation->room ?? []) : ($reservation->room ?? null);
                                $checkIn = is_string($reservation->check_in ?? null) ? new \DateTime($reservation->check_in) : ($reservation->check_in ?? new \DateTime());
                                $checkOut = is_string($reservation->check_out ?? null) ? new \DateTime($reservation->check_out) : ($reservation->check_out ?? new \DateTime());
                                ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        <?= htmlspecialchars($reservation->reservation_code ?? $reservation['reservation_code'] ?? 'N/A') ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm">
                                        Quarto <?= htmlspecialchars($room->number ?? $room['number'] ?? 'N/A') ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm">
                                        <?= $checkIn->format('d/m/Y') ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm">
                                        <?= $checkOut->format('d/m/Y') ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-semibold">
                                        R$ <?= number_format($reservation->total_price ?? $reservation['total_price'] ?? 0, 2, ',', '.') ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php
                                        $status = $reservation->status ?? $reservation['status'] ?? 'pending';
                                        $statusColors = [
                                            'pending' => 'bg-yellow-100 text-yellow-800',
                                            'confirmed' => 'bg-blue-100 text-blue-800',
                                            'checked_in' => 'bg-green-100 text-green-800',
                                            'checked_out' => 'bg-gray-100 text-gray-800',
                                            'cancelled' => 'bg-red-100 text-red-800'
                                        ];
                                        $statusLabels = [
                                            'pending' => 'Pendente',
                                            'confirmed' => 'Confirmada',
                                            'checked_in' => 'Check-in Realizado',
                                            'checked_out' => 'Check-out Realizado',
                                            'cancelled' => 'Cancelada'
                                        ];
                                        $color = $statusColors[$status] ?? 'bg-gray-100 text-gray-800';
                                        $label = $statusLabels[$status] ?? ucfirst($status);
                                        ?>
                                        <span class="px-2 py-1 rounded text-xs font-medium <?= $color ?>">
                                            <?= $label ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm">
                                        <a href="/reservations/<?= $reservation->id ?? $reservation['id'] ?>" class="text-blue-600 hover:text-blue-900">
                                            Ver Detalhes
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php
$content = ob_get_clean();
$show_navbar = true;
$show_footer = false;
$user_logged_in = true;
require_once __DIR__ . '/../layouts/hotel.php';
?>

