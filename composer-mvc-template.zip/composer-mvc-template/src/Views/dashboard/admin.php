<?php
ob_start();
$current_page = 'dashboard';
$page_title = 'Dashboard Administrador';
?>
<div>
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <!-- Header -->
        <div class="mb-8">
            <h1 class="text-3xl font-bold text-gray-900">Dashboard Administrador</h1>
            <p class="text-gray-600 mt-2">Controle total do sistema Hotel-Moz</p>
        </div>

        <!-- Estatísticas Gerais -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div class="bg-gradient-to-br from-blue-500 to-blue-600 text-white p-6 rounded-lg shadow-lg">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-blue-100 text-sm font-medium">Total de Usuários</p>
                        <p class="text-3xl font-bold mt-2"><?= count(\Core\Helpers\MockDataHelper::getUsers()) ?></p>
                    </div>
                    <div class="text-blue-300">
                        <svg class="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path>
                        </svg>
                    </div>
                </div>
            </div>

            <div class="bg-gradient-to-br from-green-500 to-green-600 text-white p-6 rounded-lg shadow-lg">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-green-100 text-sm font-medium">Reservas Hoje</p>
                        <p class="text-3xl font-bold mt-2"><?= \Core\Helpers\MockDataHelper::getStats()['today_reservations'] ?></p>
                    </div>
                    <div class="text-green-300">
                        <svg class="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                        </svg>
                    </div>
                </div>
            </div>

            <div class="bg-gradient-to-br from-purple-500 to-purple-600 text-white p-6 rounded-lg shadow-lg">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-purple-100 text-sm font-medium">Quartos Ocupados</p>
                        <p class="text-3xl font-bold mt-2"><?= \Core\Helpers\MockDataHelper::getStats()['occupied_rooms'] ?></p>
                    </div>
                    <div class="text-purple-300">
                        <svg class="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path>
                        </svg>
                    </div>
                </div>
            </div>

            <div class="bg-gradient-to-br from-orange-500 to-orange-600 text-white p-6 rounded-lg shadow-lg">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-orange-100 text-sm font-medium">Receita Mensal</p>
                        <p class="text-3xl font-bold mt-2">R$ <?= number_format(\Core\Helpers\MockDataHelper::getStats()['monthly_revenue'], 2, ',', '.') ?></p>
                    </div>
                    <div class="text-orange-300">
                        <svg class="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                    </div>
                </div>
            </div>
        </div>

        <!-- Cards de Ação Rápida -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <!-- Gestão de Usuários -->
            <div class="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow">
                <div class="flex items-center mb-4">
                    <div class="bg-blue-100 p-3 rounded-lg">
                        <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path>
                        </svg>
                    </div>
                    <h2 class="text-xl font-semibold ml-4">Gestão de Usuários</h2>
                </div>
                <p class="text-gray-600 mb-4">Gerencie usuários, permissões e roles do sistema.</p>
                <button onclick="loadUsers()" class="w-full bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                    Acessar Gestão
                </button>
            </div>

            <!-- Configurações -->
            <div class="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow">
                <div class="flex items-center mb-4">
                    <div class="bg-green-100 p-3 rounded-lg">
                        <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"></path>
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
                        </svg>
                    </div>
                    <h2 class="text-xl font-semibold ml-4">Configurações</h2>
                </div>
                <p class="text-gray-600 mb-4">Configure o sistema e suas preferências.</p>
                <button onclick="loadSettings()" class="w-full bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors">
                    Acessar Configurações
                </button>
            </div>

            <!-- Logs e Auditoria -->
            <div class="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow">
                <div class="flex items-center mb-4">
                    <div class="bg-purple-100 p-3 rounded-lg">
                        <svg class="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                        </svg>
                    </div>
                    <h2 class="text-xl font-semibold ml-4">Logs e Auditoria</h2>
                </div>
                <p class="text-gray-600 mb-4">Visualize logs e atividades do sistema.</p>
                <button onclick="loadLogs()" class="w-full bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors">
                    Ver Logs
                </button>
            </div>
        </div>

        <!-- Gestão de Quartos -->
        <div class="bg-white rounded-lg shadow-lg p-6 mb-8">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-xl font-semibold">Gestão de Quartos</h2>
                <button class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                    Adicionar Quarto
                </button>
            </div>
            <p class="text-gray-600">Gerencie quartos, tipos e preços do hotel.</p>
        </div>

        <!-- Visão Geral do Sistema -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <!-- Atividades Recentes -->
            <div class="bg-white rounded-lg shadow-lg p-6">
                <h2 class="text-xl font-semibold mb-4">Atividades Recentes</h2>
                <div class="space-y-4">
                    <div class="flex items-center space-x-3">
                        <div class="bg-blue-100 p-2 rounded-full">
                            <svg class="w-4 h-4 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                            </svg>
                        </div>
                        <div>
                            <p class="text-sm font-medium">Novo usuário registrado</p>
                            <p class="text-xs text-gray-500">Há 5 minutos</p>
                        </div>
                    </div>
                    <div class="flex items-center space-x-3">
                        <div class="bg-green-100 p-2 rounded-full">
                            <svg class="w-4 h-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                            </svg>
                        </div>
                        <div>
                            <p class="text-sm font-medium">Nova reserva criada</p>
                            <p class="text-xs text-gray-500">Há 15 minutos</p>
                        </div>
                    </div>
                    <div class="flex items-center space-x-3">
                        <div class="bg-yellow-100 p-2 rounded-full">
                            <svg class="w-4 h-4 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path>
                            </svg>
                        </div>
                        <div>
                            <p class="text-sm font-medium">Aviso: Quarto precisa de manutenção</p>
                            <p class="text-xs text-gray-500">Há 1 hora</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Informações do Sistema -->
            <div class="bg-white rounded-lg shadow-lg p-6">
                <h2 class="text-xl font-semibold mb-4">Informações do Sistema</h2>
                <div class="space-y-3">
                    <div class="flex justify-between">
                        <span class="text-gray-600">Versão do Sistema</span>
                        <span class="font-semibold">1.0.0</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-600">Última Atualização</span>
                        <span class="font-semibold"><?= date('d/m/Y') ?></span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-600">Status do Banco</span>
                        <span class="font-semibold text-green-600">Online</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-600">Usuário Logado</span>
                        <span class="font-semibold"><?= htmlspecialchars($user['name'] ?? 'Admin') ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function loadUsers() {
    alert('Funcionalidade de gestão de usuários em desenvolvimento');
    // Aqui você pode carregar uma view ou modal com lista de usuários
}

function loadSettings() {
    alert('Funcionalidade de configurações em desenvolvimento');
    // Aqui você pode carregar uma view ou modal com configurações
}

function loadLogs() {
    alert('Funcionalidade de logs em desenvolvimento');
    // Aqui você pode carregar uma view ou modal com logs
}

// Carregar estatísticas ao carregar a página
document.addEventListener('DOMContentLoaded', function() {
    // Em uma implementação real, você faria uma chamada AJAX aqui
    // Por enquanto, vamos deixar como está
});
</script>
<?php
$content = ob_get_clean();
require_once __DIR__ . '/../layouts/admin.php';
?>
