<?php
ob_start();
?>
<div class="min-h-screen py-8">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 class="text-3xl font-bold mb-8">Dashboard Gerente</h1>

        <!-- KPI Cards -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div class="bg-white p-6 rounded-lg shadow">
                <h3 class="text-lg font-semibold mb-2 text-gray-600">Total de Quartos</h3>
                <p class="text-3xl font-bold text-blue-600"><?= $stats['total_rooms'] ?? 0 ?></p>
            </div>
            <div class="bg-white p-6 rounded-lg shadow">
                <h3 class="text-lg font-semibold mb-2 text-gray-600">Ocupados</h3>
                <p class="text-3xl font-bold text-red-600"><?= $stats['occupied_rooms'] ?? 0 ?></p>
            </div>
            <div class="bg-white p-6 rounded-lg shadow">
                <h3 class="text-lg font-semibold mb-2 text-gray-600">Disponíveis</h3>
                <p class="text-3xl font-bold text-green-600"><?= $stats['available_rooms'] ?? 0 ?></p>
            </div>
            <div class="bg-white p-6 rounded-lg shadow">
                <h3 class="text-lg font-semibold mb-2 text-gray-600">Taxa de Ocupação</h3>
                <p class="text-3xl font-bold text-purple-600"><?= $stats['occupancy_rate'] ?? 0 ?>%</p>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div class="bg-white p-6 rounded-lg shadow">
                <h2 class="text-xl font-semibold mb-4">Reservas Hoje</h2>
                <p class="text-4xl font-bold text-blue-600"><?= $stats['today_reservations'] ?? 0 ?></p>
            </div>
            <div class="bg-white p-6 rounded-lg shadow">
                <h2 class="text-xl font-semibold mb-4">Ações Rápidas</h2>
                <div class="space-y-2">
                    <a href="/dashboard/receptionist" class="block bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 text-center">
                        Ver Recepção
                    </a>
                    <a href="/dashboard/housekeeper" class="block bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 text-center">
                        Ver Limpeza
                    </a>
                    <button class="w-full bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700">
                        Relatórios
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
$content = ob_get_clean();
$show_navbar = true;
$show_footer = false;
$user_logged_in = true;
require_once __DIR__ . '/../layouts/hotel.php';
?>


