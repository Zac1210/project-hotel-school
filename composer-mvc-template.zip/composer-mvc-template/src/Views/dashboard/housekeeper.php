<?php
ob_start();
?>
<div class="min-h-screen py-8">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 class="text-3xl font-bold mb-8">Dashboard Limpeza</h1>

        <!-- Quadro Kanban -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
            <!-- A Fazer -->
            <div class="bg-white rounded-lg shadow p-4">
                <h2 class="text-lg font-semibold mb-4 text-red-600">A Fazer</h2>
                <div class="space-y-3" id="hk-todo">
                    <?php if (empty($rooms_to_clean)): ?>
                        <p class="text-gray-400 text-sm">Nenhum quarto</p>
                    <?php else: ?>
                        <?php foreach ($rooms_to_clean as $room): ?>
                            <?php $room = is_array($room) ? (object) $room : $room; ?>
                            <div class="bg-red-50 border border-red-200 rounded p-3">
                                <p class="font-semibold">Quarto <?= htmlspecialchars($room->number ?? $room['number'] ?? 'N/A') ?></p>
                                <p class="text-sm text-gray-600">Andar <?= htmlspecialchars($room->floor ?? $room['floor'] ?? 'N/A') ?></p>
                                <button class="mt-2 w-full bg-blue-600 text-white px-3 py-1 rounded text-sm hover:bg-blue-700">
                                    Iniciar Limpeza
                                </button>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Em Limpeza -->
            <div class="bg-white rounded-lg shadow p-4">
                <h2 class="text-lg font-semibold mb-4 text-yellow-600">Em Limpeza</h2>
                <div class="space-y-3" id="hk-doing">
                    <?php if (empty($rooms_cleaning)): ?>
                        <p class="text-gray-400 text-sm">Nenhum quarto</p>
                    <?php else: ?>
                        <?php foreach ($rooms_cleaning as $room): ?>
                            <?php $room = is_array($room) ? (object) $room : $room; ?>
                            <div class="bg-yellow-50 border border-yellow-200 rounded p-3">
                                <p class="font-semibold">Quarto <?= htmlspecialchars($room->number ?? $room['number'] ?? 'N/A') ?></p>
                                <p class="text-sm text-gray-600">Andar <?= htmlspecialchars($room->floor ?? $room['floor'] ?? 'N/A') ?></p>
                                <button class="mt-2 w-full bg-green-600 text-white px-3 py-1 rounded text-sm hover:bg-green-700">
                                    Concluir
                                </button>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Em Inspeção -->
            <div class="bg-white rounded-lg shadow p-4">
                <h2 class="text-lg font-semibold mb-4 text-orange-600">Em Inspeção</h2>
                <div class="space-y-3">
                    <p class="text-gray-400 text-sm">Nenhum quarto</p>
                </div>
            </div>

            <!-- Concluído -->
            <div class="bg-white rounded-lg shadow p-4">
                <h2 class="text-lg font-semibold mb-4 text-green-600">Concluído</h2>
                <div class="space-y-3">
                    <p class="text-gray-400 text-sm">Nenhum quarto</p>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="/assets/js/event-bus.js"></script>
<script>
// Ouvir tarefas de limpeza criadas a partir do balcão
if (window.HotelMozBus) {
    HotelMozBus.on('housekeeping.task.created', function(evt){
        const t = evt.payload || {};
        const todo = document.getElementById('hk-todo');
        if (!todo) return;
        const priorityMap = { max: 'bg-red-100 text-red-800', high: 'bg-yellow-100 text-yellow-800', normal: 'bg-green-100 text-green-800' };
        const badge = priorityMap[t.priority] || priorityMap.normal;
        const el = document.createElement('div');
        el.className = 'bg-red-50 border border-red-200 rounded p-3';
        el.innerHTML = `
            <div class="flex items-start justify-between gap-3">
                <div>
                    <p class="font-semibold">Quarto ${t.roomNumber || ''}</p>
                    <p class="text-sm text-gray-600">Andar ${t.floor || '-'}</p>
                    <p class="text-xs text-gray-500">Check-out: ${new Date(t.checkoutAt).toLocaleTimeString()}</p>
                    ${t.notes ? `<p class="text-xs text-gray-600 mt-1">${t.notes}</p>` : ''}
                </div>
                <span class="px-2 py-1 text-xs rounded ${badge}">${t.priority === 'max' ? 'Prioridade Máxima' : t.priority === 'high' ? 'Alta' : 'Normal'}</span>
            </div>
            <button class="mt-3 w-full bg-blue-600 text-white px-3 py-1 rounded text-sm hover:bg-blue-700" data-action="start-cleaning" data-room="${t.roomNumber}">Iniciar Limpeza</button>
        `;
        todo.prepend(el);

        // Alerta sonoro usando WebAudio (beep curto)
        try {
            const ctx = new (window.AudioContext || window.webkitAudioContext)();
            const o = ctx.createOscillator();
            const g = ctx.createGain();
            o.connect(g); g.connect(ctx.destination);
            o.frequency.value = 880; g.gain.value = 0.05; o.start();
            setTimeout(()=>{ o.stop(); ctx.close(); }, 250);
        } catch(_){}
    });
}

// Mover card para "Em Limpeza" quando iniciar
document.addEventListener('click', function(e){
    const btn = e.target.closest('button[data-action="start-cleaning"]');
    if (!btn) return;
    const card = btn.closest('div.bg-red-50');
    const doing = document.getElementById('hk-doing');
    if (card && doing) {
        card.classList.remove('bg-red-50','border-red-200');
        card.classList.add('bg-yellow-50','border-yellow-200');
        btn.remove();
        const finish = document.createElement('button');
        finish.className = 'mt-3 w-full bg-green-600 text-white px-3 py-1 rounded text-sm hover:bg-green-700';
        finish.textContent = 'Concluir';
        finish.setAttribute('data-action','finish-cleaning');
        doing.prepend(card);
        card.appendChild(finish);
    }
});

// Finalizar limpeza (mock): remove do "Em Limpeza"
document.addEventListener('click', function(e){
    const btn = e.target.closest('button[data-action="finish-cleaning"]');
    if (!btn) return;
    const card = btn.closest('div');
    card.remove();
    // Em um backend real, aqui notificaríamos a recepção e marcaríamos como disponível
});
</script>
<?php
$content = ob_get_clean();
$show_navbar = true;
$show_footer = false;
$user_logged_in = true;
require_once __DIR__ . '/../layouts/hotel.php';
?>

