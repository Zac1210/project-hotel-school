<?php
ob_start();
?>
<div class="min-h-screen bg-gray-50 py-6 font-primary">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <!-- Cabeçalho Premium -->
        <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Playfair+Display:wght@600;700&display=swap');
        .font-primary { font-family: 'Inter', system-ui, sans-serif; }
        .font-secondary { font-family: 'Playfair Display', serif; }
        .shadow-premium { box-shadow: 0 8px 32px rgba(0,0,0,0.08); }
        .shadow-card { box-shadow: 0 4px 20px rgba(0,0,0,0.06); }
        .gradient-header { background: linear-gradient(135deg, #1e3a8a 0%, #3730a3 100%); }
        </style>

        <!-- Header Premium -->
        <div class="rounded-2xl p-6 mb-8 gradient-header text-white shadow-premium">
            <div class="flex items-center justify-between">
                <div class="flex items-center gap-4">
                    <div class="w-14 h-14 rounded-xl bg-white/10 flex items-center justify-center font-secondary text-2xl border-2 border-yellow-400/30">🏨</div>
                    <div>
                        <h1 class="text-3xl font-secondary font-bold">Hotel Premium</h1>
                        <p class="text-white/80 text-sm mt-1">Dashboard Recepcionista - Bem-vindo(a)</p>
                    </div>
                </div>
                <div class="flex items-center gap-6">
                    <div class="relative hidden lg:block">
                        <input type="text" placeholder="Pesquisar hóspedes, quartos..." 
                               class="w-80 rounded-full bg-white/15 backdrop-blur-sm border border-white/20 
                                      placeholder-white/70 text-white px-5 py-3 focus:bg-white/20 
                                      focus:border-white/30 transition-all outline-none" />
                        <span class="absolute right-4 top-1/2 -translate-y-1/2 text-white/70">🔍</span>
                    </div>
                    <div class="flex items-center gap-4">
                        <div class="relative">
                            <button class="w-11 h-11 rounded-full bg-white/10 hover:bg-white/20 
                                         transition-all flex items-center justify-center 
                                         backdrop-blur-sm border border-white/20">
                                🔔
                            </button>
                            <span class="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-red-500 
                                       border-2 border-blue-900 animate-pulse text-xs flex 
                                       items-center justify-center text-white">3</span>
                        </div>
                        <div class="w-11 h-11 rounded-full bg-gradient-to-br from-yellow-400 to-amber-500 
                                   border-2 border-white shadow-lg flex items-center justify-center 
                                   font-medium text-gray-800">RS</div>
                    </div>
                </div>
            </div>
            <div class="flex items-center justify-between mt-6">
                <div class="text-sm text-white/80">
                    <span id="current-date"><?= date('d/m/Y') ?></span> • 
                    <span id="current-time"><?= date('H:i') ?></span> • 
                    <span id="day-of-week"><?= date('l') ?></span>
                </div>
                <div class="flex gap-3">
                    <span class="px-3 py-1 rounded-full bg-white/10 text-xs border border-white/20">Turno: Manhã</span>
                    <span class="px-3 py-1 rounded-full bg-green-500/20 text-green-200 text-xs border border-green-500/30">Sistema Online</span>
                </div>
            </div>
        </div>

        <!-- Grid de Status em Tempo Real -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-6 gap-5 mb-8">
            <?php
            $statusCards = [
                ['label' => 'Check-ins Hoje', 'value' => '22', 'icon' => '🛎️', 'color' => 'from-blue-500 to-blue-600', 'text' => 'Hóspedes'],
                ['label' => 'Check-outs Hoje', 'value' => '18', 'icon' => '📤', 'color' => 'from-purple-500 to-purple-600', 'text' => 'Hóspedes'],
                ['label' => 'Quartos Disponíveis', 'value' => '85', 'icon' => '✅', 'color' => 'from-green-500 to-green-600', 'text' => 'Quartos'],
                ['label' => 'Quartos Ocupados', 'value' => '120', 'icon' => '🚫', 'color' => 'from-red-500 to-red-600', 'text' => 'Quartos'],
                ['label' => 'Em Limpeza', 'value' => '15', 'icon' => '🧹', 'color' => 'from-amber-500 to-amber-600', 'text' => 'Quartos'],
                ['label' => 'Reservados', 'value' => '10', 'icon' => '📅', 'color' => 'from-indigo-500 to-indigo-600', 'text' => 'Quartos']
            ];
            
            foreach($statusCards as $card): ?>
            <div class="bg-white rounded-2xl p-5 shadow-card hover:shadow-premium transition-all duration-300 
                       transform hover:-translate-y-1 border border-gray-100">
                <div class="flex items-center justify-between mb-3">
                    <div class="text-2xl"><?= $card['icon'] ?></div>
                    <div class="w-3 h-3 rounded-full bg-gradient-to-r <?= $card['color'] ?>"></div>
                </div>
                <div class="text-3xl font-bold text-gray-900 mb-1"><?= $card['value'] ?></div>
                <div class="text-sm text-gray-600 font-medium"><?= $card['label'] ?></div>
                <div class="text-xs text-gray-400 mt-1"><?= $card['text'] ?></div>
            </div>
            <?php endforeach; ?>
        </div>

        <div class="grid grid-cols-1 xl:grid-cols-3 gap-8 mb-8">
            <!-- Chegadas Pendentes -->
            <div class="xl:col-span-2">
                <div class="bg-white rounded-2xl shadow-card overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
                        <h2 class="text-xl font-semibold text-gray-900">Chegadas Pendentes</h2>
                        <span class="px-3 py-1 rounded-full bg-blue-100 text-blue-700 text-sm font-medium">4 hóspedes</span>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="w-full">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Hóspede</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quarto</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Entrada</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ações</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-100">
                                <tr class="hover:bg-gray-50 transition-colors">
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="flex items-center">
                                            <div class="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 text-sm mr-3">MS</div>
                                            <div>
                                                <div class="font-medium text-gray-900">Maria Silva</div>
                                                <div class="text-sm text-gray-500">maria.silva@email.com</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <span class="px-2 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-medium">124</span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">10:30 AM</td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <span class="px-2 py-1 bg-green-100 text-green-700 rounded-full text-xs font-medium">Confirmado</span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="flex gap-2">
                                            <button class="w-8 h-8 rounded-lg bg-blue-600 hover:bg-blue-700 text-white flex items-center justify-center transition-colors" title="Check-in">✓</button>
                                            <button class="w-8 h-8 rounded-lg bg-gray-100 hover:bg-gray-200 text-gray-600 flex items-center justify-center transition-colors" title="Ligar">📞</button>
                                            <button class="w-8 h-8 rounded-lg bg-gray-100 hover:bg-gray-200 text-gray-600 flex items-center justify-center transition-colors" title="Mensagem">✉️</button>
                                        </div>
                                    </td>
                                </tr>
                                <tr class="hover:bg-gray-50 transition-colors">
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="flex items-center">
                                            <div class="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center text-purple-600 text-sm mr-3">JP</div>
                                            <div>
                                                <div class="font-medium text-gray-900">João Pereira</div>
                                                <div class="text-sm text-gray-500">joao.pereira@email.com</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <span class="px-2 py-1 bg-purple-100 text-purple-700 rounded-full text-sm font-medium">87</span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">11:05 AM</td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <span class="px-2 py-1 bg-green-100 text-green-700 rounded-full text-xs font-medium">Confirmado</span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="flex gap-2">
                                            <button class="w-8 h-8 rounded-lg bg-blue-600 hover:bg-blue-700 text-white flex items-center justify-center transition-colors" title="Check-in">✓</button>
                                            <button class="w-8 h-8 rounded-lg bg-gray-100 hover:bg-gray-200 text-gray-600 flex items-center justify-center transition-colors" title="Ligar">📞</button>
                                        </div>
                                    </td>
                                </tr>
                                <tr class="hover:bg-gray-50 transition-colors">
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="flex items-center">
                                            <div class="w-8 h-8 rounded-full bg-yellow-100 flex items-center justify-center text-yellow-600 text-sm mr-3">AS</div>
                                            <div>
                                                <div class="font-medium text-gray-900">Ana Santos</div>
                                                <div class="text-sm text-gray-500">VIP</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <span class="px-2 py-1 bg-yellow-100 text-yellow-700 rounded-full text-sm font-medium">301</span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">12:00 PM</td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <span class="px-2 py-1 bg-yellow-100 text-yellow-700 rounded-full text-xs font-medium">VIP</span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="flex gap-2">
                                            <button class="w-8 h-8 rounded-lg bg-blue-600 hover:bg-blue-700 text-white flex items-center justify-center transition-colors" title="Check-in">✓</button>
                                            <button class="w-8 h-8 rounded-lg bg-yellow-100 hover:bg-yellow-200 text-yellow-600 flex items-center justify-center transition-colors" title="Serviço VIP">⭐</button>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Mapa de Quartos Interativo -->
            <div class="xl:col-span-1">
                <div class="bg-white rounded-2xl shadow-card overflow-hidden h-full">
                    <div class="px-6 py-4 border-b border-gray-100">
                        <h2 class="text-xl font-semibold text-gray-900">Mapa de Quartos</h2>
                        <p class="text-sm text-gray-500 mt-1">Andar 1 - Status em tempo real</p>
                    </div>
                    <div class="p-6">
                        <div class="grid grid-cols-4 gap-3 mb-6">
                            <?php
                            $sampleRooms = [
                                ['number' => '101', 'status' => 'available', 'guest' => ''],
                                ['number' => '102', 'status' => 'occupied', 'guest' => 'Silva'],
                                ['number' => '103', 'status' => 'cleaning', 'guest' => ''],
                                ['number' => '104', 'status' => 'available', 'guest' => ''],
                                ['number' => '105', 'status' => 'occupied', 'guest' => 'Costa'],
                                ['number' => '106', 'status' => 'reserved', 'guest' => ''],
                                ['number' => '107', 'status' => 'available', 'guest' => ''],
                                ['number' => '108', 'status' => 'occupied', 'guest' => 'Lima']
                            ];
                            
                            foreach($sampleRooms as $room): 
                                $statusColors = [
                                    'available' => 'bg-green-100 border-green-300 text-green-700',
                                    'occupied' => 'bg-red-100 border-red-300 text-red-700',
                                    'cleaning' => 'bg-amber-100 border-amber-300 text-amber-700',
                                    'reserved' => 'bg-blue-100 border-blue-300 text-blue-700'
                                ];
                            ?>
                            <div class="room-card <?= $statusColors[$room['status']] ?> rounded-lg p-3 text-center border-2 cursor-pointer hover:scale-105 transition-transform">
                                <div class="font-bold text-sm"><?= $room['number'] ?></div>
                                <div class="text-xs mt-1 opacity-75">
                                    <?= $room['guest'] ?: ucfirst($room['status']) ?>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        
                        <!-- Legenda -->
                        <div class="border-t pt-4">
                            <h4 class="text-sm font-medium text-gray-900 mb-2">Legenda:</h4>
                            <div class="grid grid-cols-2 gap-2 text-xs">
                                <div class="flex items-center gap-2">
                                    <div class="w-3 h-3 rounded-full bg-green-400"></div>
                                    <span class="text-gray-600">Disponível</span>
                                </div>
                                <div class="flex items-center gap-2">
                                    <div class="w-3 h-3 rounded-full bg-red-400"></div>
                                    <span class="text-gray-600">Ocupado</span>
                                </div>
                                <div class="flex items-center gap-2">
                                    <div class="w-3 h-3 rounded-full bg-amber-400"></div>
                                    <span class="text-gray-600">Limpeza</span>
                                </div>
                                <div class="flex items-center gap-2">
                                    <div class="w-3 h-3 rounded-full bg-blue-400"></div>
                                    <span class="text-gray-600">Reservado</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Saídas Pendentes e Mensagens -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <!-- Saídas Pendentes -->
            <div class="bg-white rounded-2xl shadow-card overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
                    <h2 class="text-xl font-semibold text-gray-900">Saídas Pendentes</h2>
                    <span class="px-3 py-1 rounded-full bg-purple-100 text-purple-700 text-sm font-medium">3 hóspedes</span>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Hóspede</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quarto</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Saída</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ações</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-100">
                            <tr class="hover:bg-gray-50 transition-colors">
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="flex items-center">
                                        <div class="w-8 h-8 rounded-full bg-red-100 flex items-center justify-center text-red-600 text-sm mr-3">PC</div>
                                        <div class="font-medium text-gray-900">Pedro Costa</div>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span class="px-2 py-1 bg-gray-100 text-gray-700 rounded-full text-sm font-medium">205</span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">12:00 PM</td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span class="px-2 py-1 bg-red-100 text-red-700 rounded-full text-xs font-medium">Ocupado</span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="flex gap-2">
                                        <button class="w-8 h-8 rounded-lg bg-green-600 hover:bg-green-700 text-white flex items-center justify-center transition-colors" title="Check-out">📤</button>
                                        <button class="w-8 h-8 rounded-lg bg-gray-100 hover:bg-gray-200 text-gray-600 flex items-center justify-center transition-colors" title="Fatura">🧾</button>
                                    </div>
                                </td>
                            </tr>
                            <tr class="hover:bg-gray-50 transition-colors">
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="flex items-center">
                                        <div class="w-8 h-8 rounded-full bg-pink-100 flex items-center justify-center text-pink-600 text-sm mr-3">CL</div>
                                        <div class="font-medium text-gray-900">Carla Lima</div>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span class="px-2 py-1 bg-gray-100 text-gray-700 rounded-full text-sm font-medium">150</span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">12:30 PM</td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span class="px-2 py-1 bg-amber-100 text-amber-700 rounded-full text-xs font-medium">Pendente</span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="flex gap-2">
                                        <button class="w-8 h-8 rounded-lg bg-green-600 hover:bg-green-700 text-white flex items-center justify-center transition-colors" title="Check-out">📤</button>
                                        <button class="w-8 h-8 rounded-lg bg-gray-100 hover:bg-gray-200 text-gray-600 flex items-center justify-center transition-colors" title="Lembrar">⏰</button>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Mensagens Recentes -->
            <div class="bg-white rounded-2xl shadow-card overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
                    <h2 class="text-xl font-semibold text-gray-900">Mensagens Recentes</h2>
                    <span class="px-3 py-1 rounded-full bg-green-100 text-green-700 text-sm font-medium">5 novas</span>
                </div>
                <div class="p-6 space-y-4">
                    <div class="flex items-start gap-3 p-3 bg-blue-50 rounded-lg border border-blue-100">
                        <div class="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 text-sm flex-shrink-0">204</div>
                        <div class="flex-1">
                            <div class="font-medium text-gray-900">Quarto 204</div>
                            <div class="text-sm text-gray-600 mt-1">Preciso de mais toalhas, por favor.</div>
                            <div class="text-xs text-gray-400 mt-1">10:23 AM</div>
                        </div>
                        <span class="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></span>
                    </div>
                    
                    <div class="flex items-start gap-3 p-3 hover:bg-gray-50 rounded-lg transition-colors">
                        <div class="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center text-green-600 text-sm flex-shrink-0">R</div>
                        <div class="flex-1">
                            <div class="font-medium text-gray-900">Restaurante</div>
                            <div class="text-sm text-gray-600 mt-1">Mesa reservada para Silva - 20:00</div>
                            <div class="text-xs text-gray-400 mt-1">09:45 AM</div>
                        </div>
                    </div>
                    
                    <div class="flex items-start gap-3 p-3 hover:bg-gray-50 rounded-lg transition-colors">
                        <div class="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center text-purple-600 text-sm flex-shrink-0">M</div>
                        <div class="flex-1">
                            <div class="font-medium text-gray-900">Manutenção</div>
                            <div class="text-sm text-gray-600 mt-1">Quarto 105 reparado e disponível</div>
                            <div class="text-xs text-gray-400 mt-1">09:30 AM</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Ações Rápidas -->
        <div class="mt-8 bg-white rounded-2xl shadow-card p-6">
            <h2 class="text-xl font-semibold text-gray-900 mb-6">Ações Rápidas</h2>
            <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-4">
                <button class="quick-action-btn bg-blue-600 hover:bg-blue-700 text-white">
                    <div class="text-2xl mb-2">✅</div>
                    <div class="text-sm font-medium">Novo Check-in</div>
                </button>
                <button class="quick-action-btn bg-green-600 hover:bg-green-700 text-white">
                    <div class="text-2xl mb-2">📤</div>
                    <div class="text-sm font-medium">Check-out</div>
                </button>
                <button class="quick-action-btn bg-purple-600 hover:bg-purple-700 text-white">
                    <div class="text-2xl mb-2">📋</div>
                    <div class="text-sm font-medium">Nova Reserva</div>
                </button>
                <button class="quick-action-btn bg-amber-600 hover:bg-amber-700 text-white">
                    <div class="text-2xl mb-2">🧹</div>
                    <div class="text-sm font-medium">Solicitar Limpeza</div>
                </button>
                <button class="quick-action-btn bg-red-600 hover:bg-red-700 text-white">
                    <div class="text-2xl mb-2">🔧</div>
                    <div class="text-sm font-medium">Reportar Problema</div>
                </button>
                <button class="quick-action-btn bg-gray-600 hover:bg-gray-700 text-white">
                    <div class="text-2xl mb-2">📊</div>
                    <div class="text-sm font-medium">Relatório Diário</div>
                </button>
            </div>
        </div>
    </div>
</div>

<style>
.quick-action-btn {
    @apply rounded-xl p-4 text-center transition-all transform hover:-translate-y-1 hover:shadow-lg flex flex-col items-center justify-center;
}

.room-card {
    @apply transition-all cursor-pointer;
}

.font-primary {
    font-family: 'Inter', system-ui, -apple-system, sans-serif;
}

.font-secondary {
    font-family: 'Playfair Display', serif;
}
</style>

<script>
// Atualizar relógio em tempo real
function updateClock() {
    const now = new Date();
    const timeString = now.toLocaleTimeString('pt-BR', { 
        hour: '2-digit', 
        minute: '2-digit',
        second: '2-digit'
    });
    const dateString = now.toLocaleDateString('pt-BR', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
    
    document.getElementById('current-time').textContent = timeString;
    document.getElementById('current-date').textContent = now.toLocaleDateString('pt-BR');
    document.getElementById('day-of-week').textContent = now.toLocaleDateString('pt-BR', { weekday: 'long' });
}

setInterval(updateClock, 1000);
updateClock();

// Simular notificações
document.querySelectorAll('[title="Check-in"], [title="Check-out"]').forEach(button => {
    button.addEventListener('click', function() {
        const action = this.getAttribute('title');
        // Simular ação de check-in/check-out
        this.classList.add('bg-gray-400');
        this.innerHTML = '⏳';
        setTimeout(() => {
            this.classList.remove('bg-gray-400');
            this.innerHTML = action === 'Check-in' ? '✓' : '📤';
        }, 1000);
    });
});
</script>

<?php
$content = ob_get_clean();
$show_navbar = true;
$show_footer = false;
$user_logged_in = true;
require_once __DIR__ . '/../layouts/hotel.php';
?>