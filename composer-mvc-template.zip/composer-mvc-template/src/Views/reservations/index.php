<?php
ob_start();
?>
<div class="min-h-screen py-8">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between items-center mb-8">
            <h1 class="text-3xl font-bold">Minhas Reservas</h1>
            <a href="/reservations/create" class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 font-semibold">
                Nova Reserva
            </a>
        </div>

        <?php if (empty($reservations)): ?>
            <div class="bg-white rounded-lg shadow-lg p-12 text-center">
                <p class="text-gray-600 text-lg mb-4">Você ainda não tem reservas.</p>
                <a href="/" class="inline-block bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700">
                    Fazer Primeira Reserva
                </a>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php foreach ($reservations as $reservation): ?>
                    <?php
                    // Converter array para objeto se necessário
                    $reservation = is_array($reservation) ? (object) $reservation : $reservation;
                    $room = is_array($reservation->room ?? null) ? (object) ($reservation->room ?? []) : ($reservation->room ?? null);
                    $checkIn = is_string($reservation->check_in ?? null) ? new \DateTime($reservation->check_in) : ($reservation->check_in ?? new \DateTime());
                    $checkOut = is_string($reservation->check_out ?? null) ? new \DateTime($reservation->check_out) : ($reservation->check_out ?? new \DateTime());
                    $nights = $checkIn->diff($checkOut)->days;
                    $status = $reservation->status ?? $reservation['status'] ?? 'pending';
                    ?>
                    <div class="bg-white rounded-lg shadow-lg overflow-hidden">
                        <div class="p-6">
                            <div class="flex justify-between items-start mb-4">
                                <div>
                                    <h3 class="text-xl font-bold"><?= htmlspecialchars($reservation->reservation_code ?? $reservation['reservation_code'] ?? 'N/A') ?></h3>
                                    <p class="text-sm text-gray-600">Quarto <?= htmlspecialchars($room->number ?? $room['number'] ?? 'N/A') ?></p>
                                </div>
                                <?php
                                $statusColors = [
                                    'pending' => 'bg-yellow-100 text-yellow-800',
                                    'confirmed' => 'bg-blue-100 text-blue-800',
                                    'checked_in' => 'bg-green-100 text-green-800',
                                    'checked_out' => 'bg-gray-100 text-gray-800',
                                    'cancelled' => 'bg-red-100 text-red-800'
                                ];
                                $statusLabels = [
                                    'pending' => 'Pendente',
                                    'confirmed' => 'Confirmada',
                                    'checked_in' => 'Check-in',
                                    'checked_out' => 'Check-out',
                                    'cancelled' => 'Cancelada'
                                ];
                                $color = $statusColors[$status] ?? 'bg-gray-100 text-gray-800';
                                $label = $statusLabels[$status] ?? ucfirst($status);
                                ?>
                                <span class="px-2 py-1 rounded text-xs font-medium <?= $color ?>">
                                    <?= $label ?>
                                </span>
                            </div>

                            <div class="space-y-2 mb-4">
                                <p class="text-sm"><strong>Check-in:</strong> <?= $checkIn->format('d/m/Y') ?></p>
                                <p class="text-sm"><strong>Check-out:</strong> <?= $checkOut->format('d/m/Y') ?></p>
                                <p class="text-sm"><strong>Noites:</strong> <?= $nights ?></p>
                                <p class="text-lg font-bold text-blue-600">R$ <?= number_format($reservation->total_price ?? $reservation['total_price'] ?? 0, 2, ',', '.') ?></p>
                            </div>

                            <a href="/reservations/<?= $reservation->id ?? $reservation['id'] ?>" class="block text-center bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                                Ver Detalhes
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php
$content = ob_get_clean();
$show_navbar = true;
$show_footer = false;
$user_logged_in = true;
require_once __DIR__ . '/../layouts/hotel.php';
?>

