<?php
ob_start();
?>
<div class="min-h-screen py-8">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="bg-white rounded-lg shadow-lg p-8">
            <?php
            // Garantir que temos um objeto
            $reservation = is_array($reservation) ? (object) $reservation : $reservation;
            $room = is_array($reservation->room ?? null) ? (object) ($reservation->room ?? []) : ($reservation->room ?? null);
            $checkIn = is_string($reservation->check_in ?? null) ? new \DateTime($reservation->check_in) : ($reservation->check_in ?? new \DateTime());
            $checkOut = is_string($reservation->check_out ?? null) ? new \DateTime($reservation->check_out) : ($reservation->check_out ?? new \DateTime());
            $nights = $checkIn->diff($checkOut)->days;
            $status = $reservation->status ?? $reservation['status'] ?? 'pending';
            ?>
            <div class="flex justify-between items-start mb-6">
                <div>
                    <h1 class="text-3xl font-bold mb-2">Detalhes da Reserva</h1>
                    <p class="text-gray-600">Código: <?= htmlspecialchars($reservation->reservation_code ?? $reservation['reservation_code'] ?? 'N/A') ?></p>
                </div>
                <?php
                $statusColors = [
                    'pending' => 'bg-yellow-100 text-yellow-800',
                    'confirmed' => 'bg-blue-100 text-blue-800',
                    'checked_in' => 'bg-green-100 text-green-800',
                    'checked_out' => 'bg-gray-100 text-gray-800',
                    'cancelled' => 'bg-red-100 text-red-800'
                ];
                $statusLabels = [
                    'pending' => 'Pendente',
                    'confirmed' => 'Confirmada',
                    'checked_in' => 'Check-in Realizado',
                    'checked_out' => 'Check-out Realizado',
                    'cancelled' => 'Cancelada'
                ];
                $color = $statusColors[$status] ?? 'bg-gray-100 text-gray-800';
                $label = $statusLabels[$status] ?? ucfirst($status);
                ?>
                <span class="px-4 py-2 rounded-lg text-sm font-medium <?= $color ?>">
                    <?= $label ?>
                </span>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div class="bg-gray-50 p-4 rounded-lg">
                    <h3 class="font-semibold mb-2">Informações do Quarto</h3>
                    <p class="text-gray-700">Número: <span class="font-bold"><?= htmlspecialchars($room->number ?? $room['number'] ?? 'N/A') ?></span></p>
                    <p class="text-gray-700">Tipo: <span class="font-bold"><?= htmlspecialchars(ucfirst($room->type ?? $room['type'] ?? 'N/A')) ?></span></p>
                    <p class="text-gray-700">Andar: <span class="font-bold"><?= htmlspecialchars($room->floor ?? $room['floor'] ?? 'N/A') ?></span></p>
                </div>

                <div class="bg-gray-50 p-4 rounded-lg">
                    <h3 class="font-semibold mb-2">Datas</h3>
                    <p class="text-gray-700">Check-in: <span class="font-bold"><?= $checkIn->format('d/m/Y') ?></span></p>
                    <p class="text-gray-700">Check-out: <span class="font-bold"><?= $checkOut->format('d/m/Y') ?></span></p>
                    <p class="text-gray-700">Noites: <span class="font-bold"><?= $nights ?></span></p>
                </div>

                <div class="bg-gray-50 p-4 rounded-lg">
                    <h3 class="font-semibold mb-2">Hóspedes</h3>
                    <p class="text-gray-700">Adultos: <span class="font-bold"><?= $reservation->adults ?? $reservation['adults'] ?? 1 ?></span></p>
                    <p class="text-gray-700">Crianças: <span class="font-bold"><?= $reservation->children ?? $reservation['children'] ?? 0 ?></span></p>
                    <p class="text-gray-700">Total: <span class="font-bold"><?= ($reservation->adults ?? $reservation['adults'] ?? 1) + ($reservation->children ?? $reservation['children'] ?? 0) ?> pessoas</span></p>
                </div>

                <div class="bg-gray-50 p-4 rounded-lg">
                    <h3 class="font-semibold mb-2">Valores</h3>
                    <p class="text-gray-700">Valor por noite: <span class="font-bold">R$ <?= number_format($room->price_per_night ?? $room['price_per_night'] ?? 0, 2, ',', '.') ?></span></p>
                    <p class="text-2xl font-bold text-blue-600">Total: R$ <?= number_format($reservation->total_price ?? $reservation['total_price'] ?? 0, 2, ',', '.') ?></p>
                </div>
            </div>

            <?php if ($reservation->special_requests ?? $reservation['special_requests'] ?? null): ?>
                <div class="mb-6">
                    <h3 class="font-semibold mb-2">Pedidos Especiais</h3>
                    <p class="text-gray-700 bg-gray-50 p-4 rounded-lg"><?= nl2br(htmlspecialchars($reservation->special_requests ?? $reservation['special_requests'] ?? '')) ?></p>
                </div>
            <?php endif; ?>

            <div class="flex justify-end space-x-4">
                <a href="/reservations" class="bg-gray-500 text-white px-6 py-2 rounded hover:bg-gray-600">
                    Voltar
                </a>
                <?php if ($status === 'confirmed'): ?>
                    <button class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">
                        Verificar Check-in
                    </button>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php
$content = ob_get_clean();
$show_navbar = true;
$show_footer = false;
$user_logged_in = true;
require_once __DIR__ . '/../layouts/hotel.php';
?>

