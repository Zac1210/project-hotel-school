<?php
ob_start();
?>
<div class="min-h-screen py-8">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 class="text-3xl font-bold mb-8">Nova Reserva</h1>

        <?php if ($room): ?>
            <?php 
            // Converter array para objeto se necessário
            $room = is_array($room) ? (object) $room : $room;
            ?>
            <div class="bg-white rounded-lg shadow-lg p-6 mb-6">
                <h2 class="text-xl font-semibold mb-4">Quarto Selecionado</h2>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <p class="text-gray-600">Número</p>
                        <p class="text-lg font-semibold">Quarto <?= htmlspecialchars($room->number ?? $room['number'] ?? 'N/A') ?></p>
                    </div>
                    <div>
                        <p class="text-gray-600">Tipo</p>
                        <p class="text-lg font-semibold"><?= htmlspecialchars(ucfirst($room->type ?? $room['type'] ?? 'standard')) ?></p>
                    </div>
                    <div>
                        <p class="text-gray-600">Capacidade</p>
                        <p class="text-lg font-semibold"><?= htmlspecialchars($room->capacity ?? $room['capacity'] ?? 1) ?> pessoas</p>
                    </div>
                    <div>
                        <p class="text-gray-600">Preço por noite</p>
                        <p class="text-lg font-semibold text-blue-600">R$ <?= number_format($room->price_per_night ?? $room['price_per_night'] ?? 0, 2, ',', '.') ?></p>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <form action="/reservations/store" method="POST" class="bg-white rounded-lg shadow-lg p-6" id="reservation-form" data-price="<?= htmlspecialchars($room->price_per_night ?? $room['price_per_night'] ?? 0) ?>">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token) ?>">
            <?php if ($room): ?>
                <input type="hidden" name="room_id" value="<?= $room->id ?? $room['id'] ?? 0 ?>">
            <?php endif; ?>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                    <label class="block text-gray-700 text-sm font-bold mb-2">Data de Entrada</label>
                    <input type="date" name="check_in" value="<?= htmlspecialchars($check_in ?? '') ?>" required
                           class="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:border-blue-500">
                </div>
                <div>
                    <label class="block text-gray-700 text-sm font-bold mb-2">Data de Saída</label>
                    <input type="date" name="check_out" value="<?= htmlspecialchars($check_out ?? '') ?>" required
                           class="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:border-blue-500">
                </div>
                <div>
                    <label class="block text-gray-700 text-sm font-bold mb-2">Adultos</label>
                    <input type="number" name="adults" min="1" value="<?= htmlspecialchars($adults ?? 1) ?>" required
                           class="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:border-blue-500">
                </div>
                <div>
                    <label class="block text-gray-700 text-sm font-bold mb-2">Crianças</label>
                    <input type="number" name="children" min="0" value="<?= htmlspecialchars($children ?? 0) ?>" required
                           class="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:border-blue-500">
                </div>
            </div>

            <div class="mb-6">
                <label class="block text-gray-700 text-sm font-bold mb-2">Pedidos Especiais (opcional)</label>
                <textarea name="special_requests" rows="4"
                          class="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:border-blue-500"
                          placeholder="Tem algum pedido especial? Informe-nos..."></textarea>
            </div>

            <div class="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
                <div class="bg-gray-50 rounded p-3">
                    <p class="text-sm text-gray-600">Noites</p>
                    <p class="text-xl font-bold" id="nights">-</p>
                </div>
                <div class="bg-gray-50 rounded p-3">
                    <p class="text-sm text-gray-600">Preço por noite</p>
                    <p class="text-xl font-bold">R$ <?= number_format($room->price_per_night ?? $room['price_per_night'] ?? 0, 2, ',', '.') ?></p>
                </div>
                <div class="bg-blue-50 rounded p-3">
                    <p class="text-sm text-blue-700">Total Estimado</p>
                    <p class="text-2xl font-extrabold text-blue-700" id="total">R$ 0,00</p>
                </div>
            </div>

            <p class="mt-2 text-sm" id="limit-note"></p>

            <div class="flex justify-end space-x-4 mt-4">
                <a href="/" class="bg-gray-500 text-white px-6 py-2 rounded hover:bg-gray-600">
                    Cancelar
                </a>
                <button type="submit" id="submit-btn" class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">
                    Confirmar Reserva
                </button>
            </div>
        </form>
    </div>
</div>
<script>
(function(){
  const form = document.getElementById('reservation-form');
  if (!form) return;
  const price = Number(form.getAttribute('data-price') || '0');
  const checkIn = form.querySelector('input[name="check_in"]');
  const checkOut = form.querySelector('input[name="check_out"]');
  const nightsEl = document.getElementById('nights');
  const totalEl = document.getElementById('total');
  const noteEl = document.getElementById('limit-note');
  const submitBtn = document.getElementById('submit-btn');

  function fmt(v){ return 'R$ ' + v.toFixed(2).replace('.', ','); }
  function calc(){
    const ci = new Date(checkIn.value);
    const co = new Date(checkOut.value);
    if (!(ci instanceof Date) || !(co instanceof Date) || isNaN(ci) || isNaN(co)) { return; }
    const ms = co - ci;
    const nights = Math.max(0, Math.round(ms / (1000*60*60*24)));
    nightsEl.textContent = nights > 0 ? nights : '-';
    totalEl.textContent = nights > 0 ? fmt(price * nights) : fmt(0);

    // Regra: máximo 2 noites online
    if (nights > 2) {
      submitBtn.disabled = true;
      submitBtn.classList.add('opacity-60','cursor-not-allowed');
      noteEl.textContent = 'Reservas online acima de 2 noites exigem presença na recepção.';
      noteEl.className = 'mt-2 text-sm text-red-600';
    } else {
      submitBtn.disabled = false;
      submitBtn.classList.remove('opacity-60','cursor-not-allowed');
      noteEl.textContent = nights === 0 ? 'Selecione datas válidas.' : 'Tudo certo para reservar online.';
      noteEl.className = 'mt-2 text-sm ' + (nights === 0 ? 'text-gray-500' : 'text-green-600');
    }
  }
  checkIn.addEventListener('change', calc);
  checkOut.addEventListener('change', calc);
  document.addEventListener('DOMContentLoaded', calc);
  calc();
})();
</script>
<?php
$content = ob_get_clean();
$show_navbar = true;
$show_footer = false;
$user_logged_in = true;
require_once __DIR__ . '/../layouts/hotel.php';
?>

