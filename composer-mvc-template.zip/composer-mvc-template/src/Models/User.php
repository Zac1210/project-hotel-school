<?php

namespace Source\Models;

use DateTimeImmutable;
use DateTimeInterface;
use Cycle\Annotated\Annotation\Entity;
use Cycle\Annotated\Annotation\Column;
use Cycle\Annotated\Annotation\Relation\HasMany;
use Source\Models\Reservation;

#[Entity(table: 'users')]
class User
{
    #[Column(type: 'primary')]
    public int $id;

    #[Column(type: 'string')]
    public string $name;

    #[Column(type: 'string')]
    public string $email;

    #[Column(type: 'string')]
    public string $password;

    #[Column(type: 'string')]
    public string $role; // client, receptionist, housekeeper, manager, admin

    #[Column(type: 'string', nullable: true)]
    public ?string $phone;

    #[Column(type: 'text', nullable: true)]
    public ?string $address;

    #[Column(type: 'string', nullable: true)]
    public ?string $document; // CPF/Passaporte

    #[Column(type: 'datetime', name: 'created_at')]
    public DateTimeInterface $createdAt;

    #[Column(type: 'datetime', name: 'updated_at')]
    public DateTimeInterface $updatedAt;

    #[HasMany(target: Post::class)]
    public array $posts = [];

    #[HasMany(target: Reservation::class)]
    public array $reservations = [];

    public function __construct()
    {
        $this->createdAt = new DateTimeImmutable();
        $this->updatedAt = new DateTimeImmutable();
        $this->role = 'user';
    }
}