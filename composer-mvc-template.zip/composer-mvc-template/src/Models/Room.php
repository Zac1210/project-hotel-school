<?php

namespace Source\Models;

use DateTimeImmutable;
use DateTimeInterface;
use Cycle\Annotated\Annotation\Entity;
use Cycle\Annotated\Annotation\Column;
use Cycle\Annotated\Annotation\Relation\BelongsTo;
use Cycle\Annotated\Annotation\Relation\HasMany;

#[Entity(table: 'rooms')]
class Room
{
    #[Column(type: 'primary')]
    public int $id;

    #[Column(type: 'string')]
    public string $number;

    #[Column(type: 'string')]
    public string $floor;

    #[Column(type: 'string')]
    public string $type; // single, double, suite, deluxe

    #[Column(type: 'integer')]
    public int $capacity;

    #[Column(type: 'float')]
    public float $price_per_night;

    #[Column(type: 'string')]
    public string $status; // available, occupied, cleaning, maintenance, reserved

    #[Column(type: 'text', nullable: true)]
    public ?string $description;

    #[Column(type: 'text', nullable: true)]
    public ?string $amenities; // JSON string

    #[Column(type: 'datetime', name: 'created_at')]
    public DateTimeInterface $createdAt;

    #[Column(type: 'datetime', name: 'updated_at')]
    public DateTimeInterface $updatedAt;

    public function __construct()
    {
        $this->createdAt = new DateTimeImmutable();
        $this->updatedAt = new DateTimeImmutable();
        $this->status = 'available';
    }

    public function isAvailable(): bool
    {
        return $this->status === 'available';
    }

    public function getAmenitiesArray(): array
    {
        return $this->amenities ? json_decode($this->amenities, true) : [];
    }
}


