<?php

namespace Source\Models;

use DateTimeImmutable;
use DateTimeInterface;
use Cycle\Annotated\Annotation\Entity;
use Cycle\Annotated\Annotation\Column;
use Cycle\Annotated\Annotation\Relation\BelongsTo;

#[Entity(table: 'reservations')]
class Reservation
{
    #[Column(type: 'primary')]
    public int $id;

    #[Column(type: 'string')]
    public string $reservation_code; // código único da reserva

    #[BelongsTo(target: User::class, innerKey: 'client_id', fkAction: 'CASCADE')]
    public User $client;

    #[BelongsTo(target: Room::class, innerKey: 'room_id', fkAction: 'RESTRICT')]
    public Room $room;

    #[Column(type: 'date')]
    public DateTimeInterface $check_in;

    #[Column(type: 'date')]
    public DateTimeInterface $check_out;

    #[Column(type: 'integer')]
    public int $adults;

    #[Column(type: 'integer')]
    public int $children;

    #[Column(type: 'float')]
    public float $total_price;

    #[Column(type: 'string')]
    public string $status; // pending, confirmed, checked_in, checked_out, cancelled

    #[Column(type: 'text', nullable: true)]
    public ?string $special_requests;

    #[Column(type: 'datetime', nullable: true, name: 'checked_in_at')]
    public ?DateTimeInterface $checkedInAt;

    #[Column(type: 'datetime', nullable: true, name: 'checked_out_at')]
    public ?DateTimeInterface $checkedOutAt;

    #[Column(type: 'datetime', name: 'created_at')]
    public DateTimeInterface $createdAt;

    #[Column(type: 'datetime', name: 'updated_at')]
    public DateTimeInterface $updatedAt;

    public function __construct()
    {
        $this->createdAt = new DateTimeImmutable();
        $this->updatedAt = new DateTimeImmutable();
        $this->status = 'pending';
        $this->reservation_code = $this->generateReservationCode();
        $this->adults = 1;
        $this->children = 0;
    }

    private function generateReservationCode(): string
    {
        return 'HM-' . strtoupper(substr(uniqid(), -8)) . '-' . date('Y');
    }

    public function getNights(): int
    {
        $diff = $this->check_in->diff($this->check_out);
        return (int) $diff->days;
    }

    public function canCheckIn(): bool
    {
        return $this->status === 'confirmed' || $this->status === 'pending';
    }

    public function canCheckOut(): bool
    {
        return $this->status === 'checked_in';
    }
}


