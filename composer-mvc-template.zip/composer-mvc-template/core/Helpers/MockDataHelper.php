<?php

namespace Core\Helpers;

class MockDataHelper
{
    public static function getRooms(): array
    {
        return [
            [
                'id' => 1,
                'number' => '101',
                'floor' => '1',
                'type' => 'single',
                'capacity' => 1,
                'price_per_night' => 150.00,
                'status' => 'available',
                'description' => 'Quarto confortável para 1 pessoa, com cama de solteiro, TV, WiFi e banheiro privativo.',
                'amenities' => ['WiFi', 'TV', 'Ar Condicionado', 'Banheiro Privativo'],
                'images' => [
                    'https://images.unsplash.com/photo-1505692794403-34d4982f88aa?q=80&w=1200&auto=format&fit=crop',
                    'https://images.unsplash.com/photo-1505691723518-36a5ac3b2d86?q=80&w=1200&auto=format&fit=crop'
                ],
                'size' => 20
            ],
            [
                'id' => 2,
                'number' => '102',
                'floor' => '1',
                'type' => 'double',
                'capacity' => 2,
                'price_per_night' => 250.00,
                'status' => 'available',
                'description' => 'Quarto espaçoso com cama de casal, ideal para casais.',
                'amenities' => ['WiFi', 'TV', 'Ar Condicionado', 'Frigobar', 'Banheiro Privativo'],
                'images' => [
                    'https://images.unsplash.com/photo-1501045661006-fcebe0257c3f?q=80&w=1200&auto=format&fit=crop',
                    'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?q=80&w=1200&auto=format&fit=crop'
                ],
                'size' => 26
            ],
            [
                'id' => 3,
                'number' => '201',
                'floor' => '2',
                'type' => 'suite',
                'capacity' => 3,
                'price_per_night' => 400.00,
                'status' => 'available',
                'description' => 'Suite luxuosa com sala, quarto separado e varanda com vista.',
                'amenities' => ['WiFi', 'TV', 'Ar Condicionado', 'Frigobar', 'Sala', 'Varanda', 'Vista'],
                'images' => [
                    'https://images.unsplash.com/photo-1507679799987-c73779587ccf?q=80&w=1200&auto=format&fit=crop',
                    'https://images.unsplash.com/photo-1551776235-dde6d4829808?q=80&w=1200&auto=format&fit=crop'
                ],
                'size' => 40
            ],
            [
                'id' => 4,
                'number' => '202',
                'floor' => '2',
                'type' => 'deluxe',
                'capacity' => 4,
                'price_per_night' => 500.00,
                'status' => 'reserved',
                'description' => 'Quarto Deluxe com duas camas, espaço amplo e todas as comodidades.',
                'amenities' => ['WiFi', 'TV', 'Ar Condicionado', 'Frigobar', 'Varanda', 'Jacuzzi'],
                'images' => [
                    'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?q=80&w=1200&auto=format&fit=crop',
                    'https://images.unsplash.com/photo-1521401830884-6c03c1c87ebb?q=80&w=1200&auto=format&fit=crop'
                ],
                'size' => 48
            ],
            [
                'id' => 5,
                'number' => '301',
                'floor' => '3',
                'type' => 'single',
                'capacity' => 1,
                'price_per_night' => 150.00,
                'status' => 'occupied',
                'description' => 'Quarto individual com todas as comodidades básicas.',
                'amenities' => ['WiFi', 'TV', 'Ar Condicionado'],
                'images' => [
                    'https://images.unsplash.com/photo-1484154218962-a197022b5858?q=80&w=1200&auto=format&fit=crop'
                ],
                'size' => 18
            ],
            [
                'id' => 6,
                'number' => '302',
                'floor' => '3',
                'type' => 'double',
                'capacity' => 2,
                'price_per_night' => 250.00,
                'status' => 'cleaning',
                'description' => 'Quarto duplo aconchegante.',
                'amenities' => ['WiFi', 'TV', 'Ar Condicionado', 'Frigobar'],
                'images' => [
                    'https://images.unsplash.com/photo-1505691938895-1758d7feb511?q=80&w=1200&auto=format&fit=crop'
                ],
                'size' => 24
            ],
            [
                'id' => 7,
                'number' => '303',
                'floor' => '3',
                'type' => 'suite',
                'capacity' => 3,
                'price_per_night' => 420.00,
                'status' => 'available',
                'description' => 'Suíte com varanda e vista.',
                'amenities' => ['WiFi','TV','Ar Condicionado','Frigobar','Varanda','Vista'],
                'images' => ['https://images.unsplash.com/photo-1554995207-c18c203602cb?q=80&w=1200&auto=format&fit=crop'],
                'size' => 38
            ],
            [
                'id' => 8,
                'number' => '304',
                'floor' => '3',
                'type' => 'deluxe',
                'capacity' => 4,
                'price_per_night' => 520.00,
                'status' => 'available',
                'description' => 'Deluxe com jacuzzi.',
                'amenities' => ['WiFi','TV','Ar Condicionado','Frigobar','Jacuzzi'],
                'images' => ['https://images.unsplash.com/photo-1496417263034-38ec4f0b665a?q=80&w=1200&auto=format&fit=crop'],
                'size' => 45
            ],
            [
                'id' => 9,
                'number' => '401',
                'floor' => '4',
                'type' => 'single',
                'capacity' => 1,
                'price_per_night' => 160.00,
                'status' => 'available',
                'description' => 'Standard com vista para a cidade.',
                'amenities' => ['WiFi','TV','Ar Condicionado'],
                'images' => ['https://images.unsplash.com/photo-1505691723518-36a5ac3b2d86?q=80&w=1200&auto=format&fit=crop'],
                'size' => 21
            ],
            [
                'id' => 10,
                'number' => '402',
                'floor' => '4',
                'type' => 'double',
                'capacity' => 2,
                'price_per_night' => 270.00,
                'status' => 'available',
                'description' => 'Duplo com frigobar.',
                'amenities' => ['WiFi','TV','Ar Condicionado','Frigobar'],
                'images' => ['https://images.unsplash.com/photo-1551776235-dde6d4829808?q=80&w=1200&auto=format&fit=crop'],
                'size' => 27
            ],
            [
                'id' => 11,
                'number' => '403',
                'floor' => '4',
                'type' => 'suite',
                'capacity' => 3,
                'price_per_night' => 430.00,
                'status' => 'available',
                'description' => 'Suíte executiva.',
                'amenities' => ['WiFi','TV','Ar Condicionado','Sala','Varanda'],
                'images' => ['https://images.unsplash.com/photo-1505691938895-1758d7feb511?q=80&w=1200&auto=format&fit=crop'],
                'size' => 42
            ],
            [
                'id' => 12,
                'number' => '404',
                'floor' => '4',
                'type' => 'deluxe',
                'capacity' => 4,
                'price_per_night' => 540.00,
                'status' => 'available',
                'description' => 'Deluxe amplo com varanda.',
                'amenities' => ['WiFi','TV','Ar Condicionado','Frigobar','Varanda'],
                'images' => ['https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?q=80&w=1200&auto=format&fit=crop'],
                'size' => 47
            ],
            [
                'id' => 13,
                'number' => '501',
                'floor' => '5',
                'type' => 'single',
                'capacity' => 1,
                'price_per_night' => 170.00,
                'status' => 'available',
                'description' => 'Standard renovado.',
                'amenities' => ['WiFi','TV','Ar Condicionado'],
                'images' => ['https://images.unsplash.com/photo-1501045661006-fcebe0257c3f?q=80&w=1200&auto=format&fit=crop'],
                'size' => 22
            ],
            [
                'id' => 14,
                'number' => '502',
                'floor' => '5',
                'type' => 'double',
                'capacity' => 2,
                'price_per_night' => 280.00,
                'status' => 'available',
                'description' => 'Duplo moderno.',
                'amenities' => ['WiFi','TV','Ar Condicionado','Frigobar'],
                'images' => ['https://images.unsplash.com/photo-1521401830884-6c03c1c87ebb?q=80&w=1200&auto=format&fit=crop'],
                'size' => 28
            ],
            [
                'id' => 15,
                'number' => '503',
                'floor' => '5',
                'type' => 'suite',
                'capacity' => 3,
                'price_per_night' => 450.00,
                'status' => 'available',
                'description' => 'Suíte com sala.',
                'amenities' => ['WiFi','TV','Ar Condicionado','Sala'],
                'images' => ['https://images.unsplash.com/photo-1507679799987-c73779587ccf?q=80&w=1200&auto=format&fit=crop'],
                'size' => 41
            ],
            [
                'id' => 16,
                'number' => '504',
                'floor' => '5',
                'type' => 'deluxe',
                'capacity' => 4,
                'price_per_night' => 560.00,
                'status' => 'available',
                'description' => 'Deluxe premium.',
                'amenities' => ['WiFi','TV','Ar Condicionado','Frigobar','Varanda'],
                'images' => ['https://images.unsplash.com/photo-1519710164239-da123dc03ef4?q=80&w=1200&auto=format&fit=crop'],
                'size' => 50
            ],
            [
                'id' => 17,
                'number' => '505',
                'floor' => '5',
                'type' => 'double',
                'capacity' => 2,
                'price_per_night' => 295.00,
                'status' => 'available',
                'description' => 'Duplo com vista.',
                'amenities' => ['WiFi','TV','Ar Condicionado','Varanda'],
                'images' => ['https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?q=80&w=1200&auto=format&fit=crop'],
                'size' => 29
            ],
            [
                'id' => 18,
                'number' => '506',
                'floor' => '5',
                'type' => 'single',
                'capacity' => 1,
                'price_per_night' => 175.00,
                'status' => 'available',
                'description' => 'Standard aconchegante.',
                'amenities' => ['WiFi','TV','Ar Condicionado'],
                'images' => ['https://images.unsplash.com/photo-1484154218962-a197022b5858?q=80&w=1200&auto=format&fit=crop'],
                'size' => 20
            ]
        ];
    }

    public static function getReservations(): array
    {
        return [
            [
                'id' => 1,
                'reservation_code' => 'HM-A1B2C3D4-2025',
                'client' => ['id' => 1, 'name' => 'João Silva', 'email' => 'joao@example.com'],
                'room' => ['id' => 1, 'number' => '101', 'type' => 'single'],
                'check_in' => '2025-11-10',
                'check_out' => '2025-11-15',
                'adults' => 1,
                'children' => 0,
                'total_price' => 750.00,
                'status' => 'confirmed',
                'special_requests' => 'Quarto silencioso, se possível',
                'created_at' => '2025-11-01 10:00:00'
            ],
            [
                'id' => 2,
                'reservation_code' => 'HM-E5F6G7H8-2025',
                'client' => ['id' => 1, 'name' => 'João Silva', 'email' => 'joao@example.com'],
                'room' => ['id' => 2, 'number' => '102', 'type' => 'double'],
                'check_in' => '2025-11-20',
                'check_out' => '2025-11-25',
                'adults' => 2,
                'children' => 0,
                'total_price' => 1250.00,
                'status' => 'pending',
                'special_requests' => null,
                'created_at' => '2025-11-02 14:30:00'
            ],
            [
                'id' => 3,
                'reservation_code' => 'HM-I9J0K1L2-2025',
                'client' => ['id' => 2, 'name' => 'Maria Santos', 'email' => 'maria@example.com'],
                'room' => ['id' => 3, 'number' => '201', 'type' => 'suite'],
                'check_in' => '2025-11-05',
                'check_out' => '2025-11-12',
                'adults' => 2,
                'children' => 1,
                'total_price' => 2800.00,
                'status' => 'checked_in',
                'special_requests' => 'Berço para criança',
                'checked_in_at' => '2025-11-05 15:00:00',
                'created_at' => '2025-10-25 09:00:00'
            ]
        ];
    }

    public static function getUsers(): array
    {
        return [
            [
                'id' => 1,
                'name' => 'João Silva',
                'email' => 'joao@example.com',
                'role' => 'client',
                'phone' => '+258 84 123 4567',
                'created_at' => '2025-01-15 10:00:00'
            ],
            [
                'id' => 2,
                'name' => 'Maria Santos',
                'email' => 'maria@example.com',
                'role' => 'client',
                'phone' => '+258 84 234 5678',
                'created_at' => '2025-02-20 14:30:00'
            ],
            [
                'id' => 3,
                'name' => 'Pedro Costa',
                'email' => 'pedro@example.com',
                'role' => 'receptionist',
                'phone' => '+258 84 345 6789',
                'created_at' => '2025-03-10 08:00:00'
            ]
        ];
    }

    public static function getStats(): array
    {
        return [
            'total_rooms' => 20,
            'occupied_rooms' => 8,
            'available_rooms' => 10,
            'cleaning_rooms' => 2,
            'reserved_rooms' => 0,
            'occupancy_rate' => 40.0,
            'today_reservations' => 5,
            'total_users' => 25,
            'monthly_revenue' => 125000.00,
            'pending_checkins' => 3
        ];
    }

    public static function getRoom($id)
    {
        $rooms = self::getRooms();
        foreach ($rooms as $room) {
            if ($room['id'] == $id) {
                return $room;
            }
        }
        return null;
    }

    public static function getReservation($id)
    {
        $reservations = self::getReservations();
        foreach ($reservations as $reservation) {
            if ($reservation['id'] == $id) {
                return $reservation;
            }
        }
        return null;
    }

    public static function getAvailableRooms($checkIn, $checkOut)
    {
        // Simulação: retorna todos os quartos disponíveis
        return array_filter(self::getRooms(), function($room) {
            return $room['status'] === 'available';
        });
    }
}


