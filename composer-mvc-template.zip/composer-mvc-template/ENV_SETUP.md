# Configuração do Ambiente

Este documento descreve como configurar o arquivo `.env` necessário para o funcionamento do projeto.

## Instalação do OpenSSL

**IMPORTANTE**: Para instalar as dependências com Composer, é necessário habilitar a extensão OpenSSL do PHP.

### Como habilitar o OpenSSL no Windows:

1. Localize o arquivo `php.ini` do seu PHP (geralmente em `C:\php\php.ini` ou na pasta do PHP)
2. Abra o arquivo `php.ini` em um editor de texto
3. Procure pela linha `;extension=openssl` (pode estar comentada com `;`)
4. Remova o ponto e vírgula (`;`) para descomentar: `extension=openssl`
5. Salve o arquivo
6. Reinicie o servidor web ou PHP

### Verificar se OpenSSL está habilitado:

Execute no terminal:
```bash
php -m | findstr openssl
```

Se retornar `openssl`, está habilitado. Caso contrário, siga os passos acima.

## Variáveis de Ambiente

Crie um arquivo `.env` na raiz do projeto com as seguintes variáveis:

### Banco de Dados

```env
DB_CONNECTION=mysql
DB_HOST=localhost
DB_PORT=3306
DB_DATABASE=seu_nome_do_banco
DB_USERNAME=seu_usuario
DB_PASSWORD=sua_senha
```

Para usar SQLite em vez de MySQL:
```env
DB_CONNECTION=sqlite
DB_DATABASE=caminho/para/database.sqlite
```

### Autenticação

```env
AUTH_SECRET_KEY=sua-chave-secreta-altere-em-producao
AUTH_TOKEN_ALGORITHM=sha256
AUTH_TOKEN_EXPIRY=86400
AUTH_SESSION_EXPIRY=1800
AUTH_SESSION_REGENERATE=1800
AUTH_REMEMBER_EXPIRY=2592000
```

### Email (Opcional)

```env
MAIL_HOST=smtp.gmail.com
MAIL_PORT=587
MAIL_USERNAME=seu-email@gmail.com
MAIL_PASSWORD=sua-senha-de-app
MAIL_FROM_ADDRESS=noreply@example.com
MAIL_FROM_NAME=Sistema
SUPPORT_EMAIL=support@example.com
```

### Aplicação

```env
APP_ENV=development
APP_DEBUG=true
```

## Após configurar o .env

1. Execute `composer install` para instalar as dependências
2. Execute `composer schema` para configurar o banco de dados
3. Execute `composer dev` para iniciar o servidor de desenvolvimento


