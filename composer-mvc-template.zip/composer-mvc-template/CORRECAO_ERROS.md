# Correção de Erros - Hotel-Moz

## ✅ Erros Corrigidos

### 1. Erro PDO::MYSQL_ATTR_INIT_COMMAND
**Problema**: Erro `Undefined constant PDO::MYSQL_ATTR_INIT_COMMAND`

**Solução**: A extensão PDO MySQL está habilitada, mas pode haver incompatibilidade de versão. Opções:

#### Opção A: Usar SQLite (Desenvolvimento)
Edite o arquivo `.env`:
```env
DB_CONNECTION=sqlite
DB_DATABASE=database.sqlite
```

#### Opção B: Verificar extensão MySQL no php.ini
1. Localize o php.ini: `php --ini`
2. Certifique-se de que estas linhas estão descomentadas:
```ini
extension=pdo_mysql
extension=mysqli
```

### 2. Extensão ZIP faltando
**Problema**: Composer não consegue extrair alguns pacotes

**Solução**: Habilite a extensão ZIP:
```ini
extension=zip
```

## 📋 Extensões PHP Necessárias

Verifique se estas extensões estão habilitadas:
- ✅ `pdo`
- ✅ `pdo_mysql` ou `pdo_sqlite`
- ✅ `openssl`
- ⚠️ `zip` (necessário para Composer)
- ⚠️ `curl` (recomendado para Composer)
- ⚠️ `mbstring` (recomendado)
- ⚠️ `xml` (recomendado)
- ⚠️ `json` (geralmente incluído)

### Comando para verificar:
```bash
php -m
```

## ⚠️ IMPORTANTE: Laravel vs PHP Puro

**ATENÇÃO**: Você especificou que quer desenvolver com **Laravel + Tailwind CSS + Livewire**, mas este projeto atual é um **template MVC em PHP puro** usando:
- Cycle ORM (não Eloquent)
- PHP puro (não Laravel)
- Sistema de rotas próprio (não Route do Laravel)
- Views PHP simples (não Blade)

### Opções Disponíveis:

#### Opção 1: Continuar com PHP Puro
- Adaptar os requisitos do Hotel-Moz para este framework
- Implementar as funcionalidades usando o sistema atual
- **Vantagem**: Projeto já configurado e funcionando

#### Opção 2: Criar Novo Projeto Laravel
- Criar projeto Laravel novo: `composer create-project laravel/laravel hotel-moz`
- Instalar Tailwind e Livewire
- Migrar estrutura do sistema atual
- **Vantagem**: Usa tecnologias especificadas (Laravel, Livewire)

#### Opção 3: Híbrido
- Manter backend em PHP puro
- Criar frontend separado com Laravel/API
- **Vantagem**: Flexibilidade

**Qual opção você prefere?**


