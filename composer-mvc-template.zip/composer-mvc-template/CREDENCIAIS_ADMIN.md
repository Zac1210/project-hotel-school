# 🔐 Credenciais de Acesso - Hotel-Moz

## 👤 Usuário Administrador

Para criar o usuário administrador, execute:

```bash
composer create-admin
```

Ou diretamente:

```bash
php db/create-admin.php
```

### Credenciais Padrão do Admin

- **Email**: `admin@hotelmoz.com`
- **Senha**: `admin123`
- **Role**: `admin`

⚠️ **IMPORTANTE**: Altere a senha após o primeiro login em produção!

---

## 👥 Usuários de Teste

Para criar todos os usuários de teste (admin, cliente, recepcionista, camareira, gerente):

```bash
composer create-users
```

Ou diretamente:

```bash
php db/create-test-users.php
```

### Credenciais de Teste

#### Administrador
- **Email**: `admin@hotelmoz.com`
- **Senha**: `admin123`
- **Role**: `admin`
- **Acesso**: Dashboard completo

#### Cliente
- **Email**: `cliente@teste.com`
- **Senha**: `cliente123`
- **Role**: `client`
- **Acesso**: Dashboard do cliente, reservas

#### Recepcionista
- **Email**: `recepcao@hotelmoz.com`
- **Senha**: `recep123`
- **Role**: `receptionist`
- **Acesso**: Check-in/check-out, reservas do dia

#### Camareira
- **Email**: `camareira@hotelmoz.com`
- **Senha**: `camareira123`
- **Role**: `housekeeper`
- **Acesso**: Dashboard de limpeza, quadro Kanban

#### Gerente
- **Email**: `gerente@hotelmoz.com`
- **Senha**: `gerente123`
- **Role**: `manager`
- **Acesso**: KPIs, métricas, relatórios

---

## 🚀 Como Usar

1. **Execute o schema** (cria as tabelas):
   ```bash
   composer schema
   ```

2. **Crie os usuários de teste**:
   ```bash
   composer create-users
   ```

3. **Inicie o servidor**:
   ```bash
   composer dev
   ```

4. **Acesse a página de login**:
   ```
   http://localhost:8000/auth
   ```

5. **Faça login** com qualquer uma das credenciais acima

---

## 🔒 Segurança

- ⚠️ **Nunca** use essas senhas em produção!
- ⚠️ Altere todas as senhas após o primeiro login
- ⚠️ Use senhas fortes (mínimo 12 caracteres, com letras, números e símbolos)
- ⚠️ Mantenha as credenciais seguras e não compartilhe

---

## 📝 Notas

- Todos os usuários são criados com role apropriada
- As senhas são hasheadas usando `password_hash()` (bcrypt)
- O script verifica se o usuário já existe antes de criar
- Você pode executar o script quantas vezes quiser (usuários existentes são pulados)


