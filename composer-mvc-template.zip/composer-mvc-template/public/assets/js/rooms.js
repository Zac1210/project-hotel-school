(function() {
  const state = {
    rooms: [],
    page: 1,
    pageSize: 12,
    filters: {
      type: '',
      priceMin: '',
      priceMax: '',
      amenities: [],
      sortBy: 'price_asc'
    }
  };

  const grid = document.getElementById('rooms-grid');
  const countEl = document.getElementById('rooms-count');
  const pageInfo = document.getElementById('page-info');

  function getParams() {
    const url = new URL(window.location.href);
    return Object.fromEntries(url.searchParams.entries());
  }

  function setParams() {
    const url = new URL(window.location.href);
    url.searchParams.set('page', state.page);
    Object.entries(state.filters).forEach(([k, v]) => {
      if (Array.isArray(v)) {
        url.searchParams.set(k, v.join(','));
      } else if (v !== '' && v !== null && v !== undefined) {
        url.searchParams.set(k, v);
      } else {
        url.searchParams.delete(k);
      }
    });
    history.replaceState(null, '', url);
  }

  function hydrateFiltersFromURL() {
    const p = getParams();
    state.page = parseInt(p.page || '1', 10);
    state.filters.type = p.type || '';
    state.filters.priceMin = p.priceMin || '';
    state.filters.priceMax = p.priceMax || '';
    state.filters.amenities = p.amenities ? p.amenities.split(',') : [];
    state.filters.sortBy = p.sortBy || 'price_asc';

    document.getElementById('filter-type').value = state.filters.type;
    document.getElementById('filter-price-min').value = state.filters.priceMin;
    document.getElementById('filter-price-max').value = state.filters.priceMax;
    document.getElementById('sort-by').value = state.filters.sortBy;
    document.querySelectorAll('#filter-amenities .amenity').forEach(cb => {
      cb.checked = state.filters.amenities.includes(cb.value);
    });
  }

  function sortRooms(items) {
    const arr = items.slice();
    switch (state.filters.sortBy) {
      case 'price_asc':
        arr.sort((a,b) => a.price_per_night - b.price_per_night); break;
      case 'price_desc':
        arr.sort((a,b) => b.price_per_night - a.price_per_night); break;
      case 'name_asc':
        arr.sort((a,b) => String(a.type).localeCompare(String(b.type))); break;
      case 'popular':
      case 'rating':
        // mock: keep as-is
        break;
    }
    return arr;
  }

  function filterRooms() {
    let items = state.rooms.slice();
    const f = state.filters;
    if (f.type) items = items.filter(r => r.type === f.type);
    if (f.priceMin) items = items.filter(r => r.price_per_night >= Number(f.priceMin));
    if (f.priceMax) items = items.filter(r => r.price_per_night <= Number(f.priceMax));
    if (f.amenities.length) items = items.filter(r => (r.amenities || []).some(a => f.amenities.includes(a)));
    return sortRooms(items);
  }

  function paginate(items) {
    const start = (state.page - 1) * state.pageSize;
    return items.slice(start, start + state.pageSize);
  }

  function badgeByType(type) {
    const map = { single: 'Standard', double: 'Familiar', suite: 'Suíte', deluxe: 'Deluxe' };
    return map[type] || 'Standard';
  }

  function availabilityColor(status) {
    return status === 'available' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800';
  }

  function render() {
    const filtered = filterRooms();
    const pageItems = paginate(filtered);
    const total = filtered.length;
    countEl.textContent = `${total} quarto${total!==1?'s':''} encontrados`;
    pageInfo.textContent = `Página ${state.page} de ${Math.max(1, Math.ceil(total / state.pageSize))}`;

    grid.innerHTML = pageItems.map(room => {
      const cover = (room.images && room.images[0]) || 'https://images.unsplash.com/photo-1505692794403-34d4982f88aa?q=80&w=1200&auto=format&fit=crop';
      const amenities = (room.amenities || []).slice(0,5).map(a => `<li class="flex items-center space-x-2" title="${a}">\
          <span>•</span><span>${a}</span></li>`).join('');
      return `
      <div class="bg-white rounded-lg shadow hover:shadow-lg transition overflow-hidden">
        <div class="relative group">
          <div class="h-48 bg-gray-200 overflow-hidden">
            <img src="${cover}" alt="Quarto" class="w-full h-full object-cover transform group-hover:scale-105 transition" />
          </div>
          <span class="absolute top-3 left-3 text-xs px-2 py-1 rounded ${availabilityColor(room.status)}">${room.status === 'available' ? 'Disponível' : 'Indisponível'}</span>
        </div>
        <div class="p-5">
          <div class="flex items-center justify-between mb-2">
            <span class="text-xs bg-blue-50 text-blue-700 px-2 py-1 rounded">${badgeByType(room.type)}</span>
            <span class="text-2xl font-bold text-blue-600">R$ ${Number(room.price_per_night).toFixed(2).replace('.', ',')}</span>
          </div>
          <h3 class="text-lg font-semibold mb-1">Quarto ${room.number}</h3>
          <div class="text-sm text-gray-600 mb-3 flex items-center gap-4">
            <span title="Capacidade">👥 ${room.capacity || 1}</span>
            <span title="Tamanho">📐 ${room.size || 24} m²</span>
          </div>
          <ul class="text-sm text-gray-700 space-y-1 mb-4">${amenities}</ul>
          <div class="flex items-center justify-between">
            <button class="px-4 py-2 border rounded-lg hover:bg-gray-50" data-action="details" data-id="${room.id}">Ver Detalhes</button>
            <a class="px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700" href="/reservations/create?room_id=${room.id}">Reservar Agora</a>
          </div>
        </div>
      </div>`;
    }).join('');

    setParams();
  }

  function openModal(contentHtml) {
    const modal = document.getElementById('room-modal');
    document.getElementById('modal-content').innerHTML = contentHtml;
    modal.classList.remove('hidden');
    modal.classList.add('flex');
  }
  function closeModal() {
    const modal = document.getElementById('room-modal');
    modal.classList.add('hidden');
    modal.classList.remove('flex');
  }

  function bindEvents() {
    document.getElementById('apply-filters').addEventListener('click', () => {
      state.page = 1;
      state.filters.type = document.getElementById('filter-type').value;
      state.filters.priceMin = document.getElementById('filter-price-min').value;
      state.filters.priceMax = document.getElementById('filter-price-max').value;
      state.filters.amenities = Array.from(document.querySelectorAll('#filter-amenities .amenity:checked')).map(x => x.value);
      state.filters.sortBy = document.getElementById('sort-by').value;
      render();
    });
    document.getElementById('clear-filters').addEventListener('click', () => {
      document.getElementById('filter-type').value = '';
      document.getElementById('filter-price-min').value = '';
      document.getElementById('filter-price-max').value = '';
      document.querySelectorAll('#filter-amenities .amenity').forEach(x => x.checked = false);
      document.getElementById('sort-by').value = 'price_asc';
      state.page = 1;
      state.filters = { type: '', priceMin: '', priceMax: '', amenities: [], sortBy: 'price_asc' };
      render();
    });
    document.getElementById('sort-by').addEventListener('change', () => {
      state.page = 1;
      state.filters.sortBy = document.getElementById('sort-by').value;
      render();
    });
    document.getElementById('prev-page').addEventListener('click', () => {
      if (state.page > 1) { state.page--; render(); }
    });
    document.getElementById('next-page').addEventListener('click', () => {
      const total = filterRooms().length;
      const maxPage = Math.max(1, Math.ceil(total / state.pageSize));
      if (state.page < maxPage) { state.page++; render(); }
    });
    document.getElementById('rooms-grid').addEventListener('click', async (e) => {
      const btn = e.target.closest('button[data-action="details"]');
      if (!btn) return;
      const id = btn.getAttribute('data-id');
      const res = await fetch(`/rooms/${id}`);
      const data = await res.json();
      const r = data.data.room;
      const cover = (r.images && r.images[0]) || 'https://images.unsplash.com/photo-1505692794403-34d4982f88aa?q=80&w=1200&auto=format&fit=crop';
      const html = `
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div class="h-64 bg-gray-100 overflow-hidden rounded-lg">
            <img src="${cover}" class="w-full h-full object-cover" />
          </div>
          <div>
            <h4 class="text-lg font-semibold mb-2">Quarto ${r.number} • ${badgeByType(r.type)}</h4>
            <p class="text-gray-700 mb-4">${r.description || 'Quarto confortável e bem equipado.'}</p>
            <ul class="text-sm text-gray-700 space-y-1 mb-4">${(r.amenities||[]).map(a=>`<li>• ${a}</li>`).join('')}</ul>
            <div class="text-2xl font-bold text-blue-600 mb-4">R$ ${Number(r.price_per_night).toFixed(2).replace('.', ',')} / noite</div>
            <a href="/reservations/create?room_id=${r.id}" class="inline-block px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700">Reservar Agora</a>
          </div>
        </div>`;
      document.getElementById('modal-title').textContent = `Quarto ${r.number}`;
      openModal(html);
    });
    document.getElementById('modal-close').addEventListener('click', closeModal);
    document.getElementById('room-modal').addEventListener('click', (e) => { if (e.target.id === 'room-modal') closeModal(); });
  }

  function init() {
    // Rooms are rendered server-side via MockDataHelper; we pull from a global injected via script if needed
    // For now, fetch from a data attribute or hydrate from PHP via JSON script tag later.
    // Since we don't have that, query a hidden dataset: we can reconstruct from DOM or make a tiny endpoint.
    // We already have PHP injected nothing, so fetch options from window.__rooms if exists, otherwise via inline JSON fallback.
    // To keep it simple, fetch from /rooms/options to warm cache, then set rooms from embedded tag if provided.

    // Try to read rooms from a meta tag created on the page (optional)
    try {
      // Server provided rooms via script tag? If not, fallback to reading from a data attribute on body
      state.rooms = window.__rooms || [];
    } catch (_) { state.rooms = []; }

    // If server didn't inject, request minimal JSON using the existing markup would be complex; instead, embed via PHP later.
    // When rooms are empty, show placeholder cards until user interacts; but we can inject via inline JSON in the view later if needed.
    if (!state.rooms.length) {
      // as a fallback, make a tiny request to the current page's dataset via a script id if present
      const script = document.getElementById('rooms-json');
      if (script) {
        try { state.rooms = JSON.parse(script.textContent || '[]'); } catch (_) {}
      }
    }

    hydrateFiltersFromURL();
    bindEvents();
    render();
  }

  document.addEventListener('DOMContentLoaded', init);
})();


