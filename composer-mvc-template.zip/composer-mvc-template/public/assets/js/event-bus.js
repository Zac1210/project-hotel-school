(function(global){
  const channelName = 'hotelmoz-bus-v1';
  let bc = null;
  try { bc = new BroadcastChannel(channelName); } catch(_) {}

  function uid(){ return Date.now().toString(36) + Math.random().toString(36).slice(2); }

  const listeners = {};

  function on(type, handler){
    (listeners[type] = listeners[type] || []).push(handler);
  }

  function emit(type, payload){
    const evt = { id: uid(), type, payload, ts: Date.now() };
    // local listeners
    (listeners[type]||[]).forEach(h => { try { h(evt); } catch(e){} });
    // cross-tab
    if (bc) {
      bc.postMessage(evt);
    } else {
      try {
        localStorage.setItem(channelName, JSON.stringify(evt));
        localStorage.removeItem(channelName);
      } catch(_) {}
    }
  }

  function handleMessage(evt){
    const data = evt.data || null;
    if (!data || !data.type) return;
    (listeners[data.type]||[]).forEach(h => { try { h(data); } catch(e){} });
  }

  if (bc) bc.onmessage = handleMessage;
  window.addEventListener('storage', function(e){
    if (e.key !== channelName || !e.newValue) return;
    try { handleMessage({ data: JSON.parse(e.newValue) }); } catch(_) {}
  });

  global.HotelMozBus = { on, emit };
})(window);


