(function(){
  // Relógio premium
  const clock = document.getElementById('clock');
  function tick(){
    if (!clock) return;
    const d = new Date();
    clock.textContent = d.toLocaleString(undefined, { hour:'2-digit', minute:'2-digit', second:'2-digit' });
  }
  setInterval(tick, 1000); tick();

  // Notificações badge demo
  const badge = document.getElementById('notif-badge');
  const btn = document.getElementById('notif');
  if (btn && badge) {
    btn.addEventListener('click', ()=>{ badge.style.display='none'; });
  }

  // Skeleton loaders placeholder (futuro)
})();


