<?php

return array_merge(
    include 'web.php',
    include 'api.php',
    include 'auth.php'
);