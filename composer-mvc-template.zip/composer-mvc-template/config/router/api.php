<?php

return [
    '/api/users' => [
        'methods' => ['GET'],
        'controller' => 'Api\\UserController@index'
    ],
    '/api/users/{id}' => [
        'methods' => ['GET'],
        'controller' => 'Api\\UserController@show'
    ],
    '/api/posts' => [
        'methods' => ['GET'],
        'controller' => 'Api\\PostController@index'
    ],
    '/api/posts/{id}' => [
        'methods' => ['GET'],
        'controller' => 'Api\\PostController@show'
    ],
    '/api/auth/login' => [
        'methods' => ['POST'],
        'controller' => 'Api\\AuthController@login'
    ],
    // Family & Capacity APIs (mock)
    '/api/check-capacity' => [
        'methods' => ['POST'],
        'controller' => 'Api\\FamilyController@checkCapacity'
    ],
    '/api/family-suggestions/{roomTypeId}' => [
        'methods' => ['GET'],
        'controller' => 'Api\\FamilyController@familySuggestions'
    ],
    '/api/calculate-extra-charges' => [
        'methods' => ['POST'],
        'controller' => 'Api\\FamilyController@calculateExtraCharges'
    ],
    '/api/setup-family-room/{reservationId}' => [
        'methods' => ['PUT'],
        'controller' => 'Api\\FamilyController@setupFamilyRoom'
    ]
];