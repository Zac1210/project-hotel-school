<?php

// Rotas de autenticação estão definidas em web.php
// Este arquivo pode ser usado para rotas de autenticação adicionais específicas
return [];