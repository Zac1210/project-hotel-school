<?php

return [
    '/' => 'HomeController@index',
    '/about' => 'HomeController@about',
    '/contact' => 'HomeController@contact',

    // Auth routes
    '/auth' => 'AuthController@showAuth',
    '/login' => [
        'methods' => ['POST'],
        'controller' => 'AuthController@login'
    ],
    '/register' => [
        'methods' => ['POST'],
        'controller' => 'AuthController@register'
    ],
    '/logout' => [
        'methods' => ['GET', 'POST'],
        'controller' => 'AuthController@logout'
    ],

    // Post routes
    '/posts' => 'PostController@index',
    '/posts/{id}' => [
        'methods' => ['GET'],
        'controller' => 'PostController@show'
    ],
    '/posts/create' => [
        'methods' => ['GET', 'POST'],
        'controller' => 'PostController@create'
    ],
    '/posts/store' => [
        'methods' => ['POST'],
        'controller' => 'PostController@store'
    ],
    '/posts/{id}/edit' => [
        'methods' => ['GET', 'POST'],
        'controller' => 'PostController@edit'
    ],
    '/posts/{id}/update' => [
        'methods' => ['POST'],
        'controller' => 'PostController@update'
    ],
    '/posts/{id}/delete' => [
        'methods' => ['POST'],
        'controller' => 'PostController@delete'
    ],
    '/new-post' => 'PostController@create',

    // Hotel routes
    '/' => 'HotelController@index',
    '/search' => 'HotelController@search',

    // Dashboard routes
    '/dashboard' => 'DashboardController@index',
    '/dashboard/client' => 'DashboardController@client',
    '/dashboard/receptionist' => 'DashboardController@receptionist',
    '/dashboard/housekeeper' => 'DashboardController@housekeeper',
    '/dashboard/manager' => 'DashboardController@manager',
    '/dashboard/admin' => 'DashboardController@admin',

    // Reservation routes
    '/reservations' => 'ReservationController@index',
    '/reservations/create' => [
        'methods' => ['GET', 'POST'],
        'controller' => 'ReservationController@create'
    ],
    '/reservations/{id}' => [
        'methods' => ['GET'],
        'controller' => 'ReservationController@show'
    ],
    '/reservations/store' => [
        'methods' => ['POST'],
        'controller' => 'ReservationController@store'
    ]
        ,
        // Rooms page
        '/rooms' => 'RoomController@index',
        '/rooms/{id}' => [
            'methods' => ['GET'],
            'controller' => 'RoomController@show'
        ],
        '/rooms/check-availability' => [
            'methods' => ['GET'],
            'controller' => 'RoomController@checkAvailability'
        ],
        '/rooms/options' => [
            'methods' => ['GET'],
            'controller' => 'RoomController@getFilterOptions'
        ]
];