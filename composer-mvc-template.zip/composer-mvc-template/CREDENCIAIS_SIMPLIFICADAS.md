# 🔐 Credenciais de Acesso - Hotel-Moz (Simplificado)

## 👤 Único Usuário: Administrador

O sistema agora possui **apenas uma conta de administrador** para testes.

### 📋 Credenciais

- **Email**: `admin@hotelmoz.com`
- **Senha**: `admin123`
- **Role**: `admin`

---

## 🚀 Como Criar o Usuário Admin

### Opção 1: Via Composer (Recomendado)
```bash
composer create-admin
```

### Opção 2: Diretamente
```bash
php db/create-admin-only.php
```

**⚠️ ATENÇÃO**: Este script irá **DELETAR todos os usuários existentes** antes de criar o admin!

---

## 📝 Fluxo de Autenticação

1. Acesse: `http://localhost:8000/auth`
2. Faça login com as credenciais do admin
3. **Redirecionamento automático** para `/dashboard/admin`
4. Dashboard com menu lateral profissional

---

## 🎨 Dashboard Admin

O dashboard do administrador possui:

- **Menu Lateral Profissional** com:
  - Dashboard
  - Reservas
  - Quartos
  - Usuários
  - Relatórios
  - Configurações
  - Link para página inicial
  - Informações do usuário logado
  - Botão de logout

- **Cards de Estatísticas**:
  - Total de Usuários
  - Reservas Hoje
  - Quartos Ocupados
  - Receita Mensal

- **Módulos de Gestão**:
  - Gestão de Usuários
  - Configurações
  - Logs e Auditoria
  - Gestão de Quartos

- **Atividades Recentes** e **Informações do Sistema**

---

## 🔒 Segurança

- ⚠️ **Nunca** use essa senha em produção!
- ⚠️ Altere a senha após o primeiro login
- ⚠️ Use senhas fortes em produção (mínimo 12 caracteres)
- ⚠️ Mantenha as credenciais seguras

---

## 📝 Notas

- O script `create-admin-only.php` remove TODOS os usuários antes de criar o admin
- Isso garante que apenas o admin exista no sistema
- O redirecionamento automático leva o admin direto para `/dashboard/admin`
- O menu lateral é responsivo e profissional


