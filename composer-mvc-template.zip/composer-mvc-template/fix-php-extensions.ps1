# Script para verificar e corrigir extensoes PHP
Write-Host "Verificando extensoes PHP necessarias..." -ForegroundColor Yellow

$required = @('pdo', 'pdo_mysql', 'openssl', 'zip', 'curl', 'mbstring', 'xml', 'json')
$missing = @()

Write-Host "`nExtensoes instaladas:" -ForegroundColor Cyan
$installed = php -m 2>&1 | Select-String -Pattern "^\w+$"

foreach ($ext in $required) {
    $found = $installed | Select-String -Pattern "^$ext$"
    if ($found) {
        Write-Host "  [OK] $ext" -ForegroundColor Green
    } else {
        Write-Host "  [FALTA] $ext" -ForegroundColor Red
        $missing += $ext
    }
}

if ($missing.Count -gt 0) {
    Write-Host "`nExtensoes faltando: $($missing -join ', ')" -ForegroundColor Red
    Write-Host "`nPara habilitar:" -ForegroundColor Yellow
    Write-Host "1. Execute: php --ini" -ForegroundColor Cyan
    Write-Host "2. Abra o arquivo php.ini indicado" -ForegroundColor Cyan
    Write-Host "3. Procure e descomente as linhas:" -ForegroundColor Cyan
    foreach ($ext in $missing) {
        if ($ext -eq 'pdo_mysql') {
            Write-Host "   extension=pdo_mysql" -ForegroundColor White
            Write-Host "   extension=mysqli" -ForegroundColor White
        } elseif ($ext -eq 'json') {
            Write-Host "   (json geralmente ja vem habilitado)" -ForegroundColor Gray
        } else {
            Write-Host "   extension=$ext" -ForegroundColor White
        }
    }
    Write-Host "4. Salve e reinicie o servidor PHP" -ForegroundColor Cyan
} else {
    Write-Host "`nTodas as extensoes necessarias estao instaladas!" -ForegroundColor Green
}

Write-Host "`nVerificando problema PDO MySQL..." -ForegroundColor Yellow
try {
    $test = php -r "echo defined('PDO::MYSQL_ATTR_INIT_COMMAND') ? 'OK' : 'ERRO';"
    if ($test -eq 'OK') {
        Write-Host "PDO MySQL: OK" -ForegroundColor Green
    } else {
        Write-Host "PDO MySQL: Constante nao definida (pode ser versao)" -ForegroundColor Yellow
        Write-Host "Solucao alternativa: Use SQLite no .env" -ForegroundColor Cyan
    }
} catch {
    Write-Host "Erro ao verificar PDO" -ForegroundColor Red
}


